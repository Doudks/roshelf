(()=>{
'use strict';
if(window.__RBLXS_LOADED__)return;window.__RBLXS_LOADED__=true;
const CATS=['Quero muito jogar','Jogaria um pouco','Jogaria no ódio','Posso testar','Só jogaria numa noite de lua azul','Nem me chama'];
const KEYS=['quero_muito_jogar','jogaria_um_pouco','jogaria_no_odio','posso_testar','lua_azul','nem_me_chama'];
const STORAGE='rblxs_local_games_v01';
const empty=()=>[[],[],[],[],[],[]];
let ownLists=empty(),ownLoaded=false,localCount=0,profileTab=0,current=0,oauthProfile=null;
let modal=false,busy=false,loginBusy=false,lastRoute='',searchResults=[],searchStatus='',searchQuery='';
let profileSearchOpen=false,profileSearchQuery='',profileSearchCategory='all',profileSearchSort='custom',profileSearchUserId='';
let featuredIds=[],featuredSaving=false,featuredEditing=false,featuredDraft=[],featuredEditError='',featuredPickerQuery='',featuredDragging=null,ownCategories=[],categoriesOpen=false,categoryStatus='',viewingId='',viewData=null,viewLoading=false,viewError='',requestSerial=0;
const app=document.createElement('div');app.id='rblxs-app';document.body.append(app);
const el=(tag,cls,txt)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(txt!==undefined)e.textContent=txt;return e};
const btn=(txt,fn,cls='rs-btn')=>{const b=el('button',cls,txt);b.type='button';b.addEventListener('click',fn);return b};
const clear=e=>e.replaceChildren();
const msg=(kind,body={})=>new Promise((resolve,reject)=>chrome.runtime.sendMessage({kind,...body},result=>{if(chrome.runtime.lastError)return reject(Error(chrome.runtime.lastError.message));if(!result?.ok)return reject(Error(result?.error||'Ocorreu um erro.'));resolve(result)}));
const gameUrl=g=>g.placeId?`https://www.roblox.com/games/${encodeURIComponent(g.placeId)}`:null;
const imageUrl=g=>/^https:\/\/tr\.rbxcdn\.com\//.test(g.image||'')?g.image:'';
const sortedCats=()=>ownCategories.slice().sort((a,b)=>Number(a.sort_order)-Number(b.sort_order));
const selectedCategory=i=>sortedCats()[i]?.name||CATS[i]||'Categoria';
const viewedProfileId=()=>((location.pathname.match(/(?:^|\/)users\/(\d+)\/profile(?:\/|$)/i)||[])[1]||'');
const isOwn=()=>Boolean(oauthProfile && viewedProfileId()===oauthProfile.id);
function toLists(data){
  const cats=(data?.categories||[]).slice().sort((a,b)=>a.sort_order-b.sort_order);
  const l=cats.length?cats.map(()=>[]):empty();
  for(const x of data?.games||[]){
    const i=cats.length?cats.findIndex(c=>c.id===x.category_id||(!x.category_id&&c.legacy_key===x.category)):KEYS.indexOf(x.category);
    if(i<0||!x.universe_id)continue;
    l[i].push({id:String(x.universe_id),placeId:x.place_id?String(x.place_id):'',name:x.game_name||'Jogo',image:x.image_url||'',sort_order:x.sort_order||0});
  }
  return l;
}
function notifyError(e){searchStatus=String(e.message||e);busy=false;drawEditor()}
async function fetchOwn(){if(!oauthProfile){ownLists=empty();ownLoaded=false;drawEditor();return}const id=oauthProfile.id;try{const data=await msg('ROSHELF_OWNER_LIST');if(oauthProfile?.id!==id)return;if(!categorySending&&categoryRevision===0)ownCategories=data.categories||[];if(!categorySavedSnapshot)setCategoryBaseline();if(!categoryRevision&&!categorySending)ownLists=toLists(data);if(!featuredSaving)featuredIds=(data.games||[]).filter(g=>g.featured_position!=null).sort((a,b)=>a.featured_position-b.featured_position).map(g=>String(g.universe_id)).slice(0,3);ownLoaded=true;if(viewedProfileId()===id){viewData=data;viewLoading=false;viewError='';refreshProfile()}drawEditor()}catch(e){searchStatus='Erro ao carregar sua lista: '+e.message;drawEditor()}}
async function fetchViewed(id){const serial=++requestSerial;viewingId=id;viewLoading=true;viewError='';viewData=null;refreshProfile();try{const data=oauthProfile?.id===id?await msg('ROSHELF_OWNER_LIST'):await msg('ROSHELF_GET_LIST',{userId:id});if(serial!==requestSerial||viewingId!==id)return;viewData=data;viewLoading=false;viewError='';if(oauthProfile?.id===id){if(!categorySending&&categoryRevision===0)ownCategories=data.categories||[];if(!categorySavedSnapshot)setCategoryBaseline();if(!categoryRevision&&!categorySending)ownLists=toLists(data);ownLoaded=true}refreshProfile();drawEditor()}catch(e){if(serial!==requestSerial||viewingId!==id)return;viewLoading=false;viewError=e.message;refreshProfile()}}
async function requestAuth(kind){if(loginBusy)return;if(categorySending||categoryRevision>0){categoryStatus='Feche as configurações e espere salvar antes de trocar de conta.';drawEditor();return;}categoryEpoch++;categoryRevision=0;categorySavedSnapshot=null;featuredEditing=false;featuredDraft=[];featuredEditError='';featuredPickerQuery='';featuredIds=[];loginBusy=true;drawEditor();try{const reply=await msg(kind);oauthProfile=kind==='ROSHELF_LOGOUT'?null:(reply.profile||null);ownLists=empty();ownCategories=[];ownLoaded=false;searchResults=[];searchStatus='';if(oauthProfile)await fetchOwn();if(viewedProfileId())await fetchViewed(viewedProfileId())}catch(e){searchStatus='Erro de autenticação: '+e.message}finally{loginBusy=false;drawEditor()}}
function authPane(){const box=el('div','rs-auth-box');const left=el('div','rs-auth-left');if(oauthProfile){if(/^https:\/\/tr\.rbxcdn\.com\//.test(oauthProfile.picture||'')){const avatar=el('img','rs-auth-avatar');avatar.src=oauthProfile.picture;avatar.alt='Avatar';left.append(avatar)}left.append(el('strong','',oauthProfile.displayName||oauthProfile.username||'Conta conectada'));left.append(el('span','rs-muted rs-small','@'+(oauthProfile.username||'Roblox')+' · Sua lista online'))}else{left.append(el('strong','','Conectar com Roblox'));left.append(el('span','rs-muted rs-small','Faça login com OAuth para editar sua própria lista.'))}box.append(left);const b=btn(loginBusy?'Aguarde...':oauthProfile?'Desconectar':'Conectar com Roblox',()=>requestAuth(oauthProfile?'ROSHELF_LOGOUT':'ROSHELF_LOGIN'));b.disabled=loginBusy||busy;box.append(b);return box}
function refreshLocalCount(){msg('ROSHELF_LOCAL_COUNT').then(x=>{localCount=x.count||0;if(modal)drawEditor()}).catch(()=>{})}
function tabItems(container,selected,onChoose){const tabs=el('div','rs-tabs');const cats=sortedCats();(cats.length?cats.map(c=>c.name):CATS).forEach((cat,i)=>{const b=btn(cat,()=>onChoose(i),'rs-tab');b.dataset.active=String(i===selected);b.dataset.rsTarget=String(i);b.addEventListener('dragover',e=>{if(draggedGameId){e.preventDefault();b.classList.add('rs-drop-target')}});b.addEventListener('dragleave',()=>b.classList.remove('rs-drop-target'));b.addEventListener('drop',e=>{e.preventDefault();b.classList.remove('rs-drop-target');if(draggedGameId)void moveGameTo(draggedGameId,i)});tabs.append(b)});container.append(tabs)}
let draggedGameId=null;
async function toggleFeatured(g){
  if(featuredSaving || !oauthProfile)return;
  const id=String(g.id), before=[...featuredIds];
  if(featuredIds.includes(id))featuredIds=featuredIds.filter(x=>x!==id);
  else {
    if(featuredIds.length>=3){searchStatus='Máximo de três destaques. Remova um primeiro.';drawEditor();return;}
    featuredIds=[...featuredIds,id];
  }
  featuredSaving=true;
  searchStatus='Salvando destaques...';drawEditor();
  try{
    // Persist staged additions before featuring them; server only accepts owned games.
    await msg('ROSHELF_COMMIT_GAMES',{ownerId:oauthProfile.id});
    await msg('ROSHELF_FEATURED_SET',{games:featuredIds});
    searchStatus='Destaques salvos!';
    if(viewedProfileId()===oauthProfile.id)await fetchViewed(oauthProfile.id);
  }catch(e){featuredIds=before;searchStatus='Não foi possível salvar os destaques: '+e.message;}
  finally{featuredSaving=false;drawEditor();}
}
function gameCard(g,remove){const item=el('div','rs-game');
if(remove){item.draggable=true;item.title='Arraste para outra categoria ou outra posição';item.addEventListener('dragstart',e=>{draggedGameId=String(g.id);e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',String(g.id));});item.addEventListener('dragend',()=>{draggedGameId=null;document.querySelectorAll('.rs-drop-target').forEach(n=>n.classList.remove('rs-drop-target'))});item.addEventListener('dragover',e=>{if(draggedGameId){e.preventDefault();item.classList.add('rs-drop-target')}});item.addEventListener('dragleave',()=>item.classList.remove('rs-drop-target'));item.addEventListener('drop',e=>{e.preventDefault();item.classList.remove('rs-drop-target');if(draggedGameId)void moveGameTo(draggedGameId,current,String(g.id));});}
const url=gameUrl(g);const a=el('a','rs-local-card-link');if(url){a.href=url;a.target='_blank';a.rel='noopener noreferrer'}else a.removeAttribute('href');const img=el('img');img.src=imageUrl(g)||'';img.alt='';img.loading='lazy';a.append(img,el('div','rs-game-name',g.name));item.append(a);if(remove){const star=btn(featuredIds.includes(String(g.id))?'★ Destacado':'☆ Destacar',()=>void toggleFeatured(g),'rs-btn rs-featured');star.disabled=featuredSaving;star.title='Opcional: até três jogos destacados';item.append(star);const move=btn('Mover para...',()=>showMovePicker(g),'rs-btn rs-move');item.append(move);const b=btn('×',()=>removeGame(g),'rs-game-remove');b.title='Remover';b.disabled=busy;item.append(b)}return item}
// Debounce: a interface muda de imediato; a API recebe apenas o estado final
// apos 1 segundo de inatividade. Nunca sinalizar privacidade como salva antes do ACK.
let categoryJobs=[],categorySending=false,categoryEpoch=0;
let categoryTimer=null, categoryRevision=0, categorySavedSnapshot=null;
const categoryOrder=()=>ownCategories.sort((a,b)=>Number(a.sort_order)-Number(b.sort_order));
const cloneCategories=items=>items.map(c=>({...c}));
const isPendingId=id=>String(id).startsWith('pending-');
function repaintCategories(){
  categoryOrder();
  if(viewedProfileId()===oauthProfile?.id && viewData){
    // Apenas representacao local para a dona; servidor e autoridade sobre privacidade.
    viewData={...viewData,categories:cloneCategories(ownCategories)};
    refreshProfile();
  }
  drawEditor();
}
function setCategoryBaseline(){
  if(categoryTimer!==null)clearTimeout(categoryTimer);
  categoryTimer=null;categorySavedSnapshot=cloneCategories(ownCategories);
}
function queueCategorySave(){
  categoryRevision++;
  categoryStatus='Alteracoes locais pendentes — salvas ao sair das configuracoes.';
  if(categoryTimer!==null)clearTimeout(categoryTimer);
  categoryTimer=null;
  repaintCategories();
}
function syncCategorySnapshot(saved){
  // Preservar edicoes feitas enquanto a rede respondia.
  categorySavedSnapshot=cloneCategories(saved);
}
async function flushCategoryJobs(){
  if(categorySending)return;
  if(!oauthProfile||!categorySavedSnapshot)return;
  categorySending=true;
  const epoch=categoryEpoch,account=oauthProfile.id;
  let snapshot=cloneCategories(categorySavedSnapshot);
  const current=cloneCategories(ownCategories);
  const revision=categoryRevision;
  const currentIds=new Set(current.map(c=>c.id));
  try{
    categoryStatus='Salvando no servidor...';drawEditor();
    // Criar somente categorias que continuem presentes apos o debounce.
    for(const c of current.filter(c=>isPendingId(c.id))){
      const result=await msg('ROSHELF_CATEGORY_CREATE',{name:c.name,preference:c.preference,isPrivate:c.is_private});
      if(!result.category?.id)throw Error('Servidor nao retornou ID da categoria.');
      const actualId=result.category.id;
      ownCategories=ownCategories.map(x=>x.id===c.id?{...x,id:actualId,legacy_key:null}:x);
      current.forEach(x=>{if(x.id===c.id)x.id=actualId});
      snapshot.push({...result.category});
      syncCategorySnapshot(snapshot);
    }
    // Persistir somente diferencas entre o snapshot salvo e o ultimo estado.
    const initial=new Map(snapshot.map(c=>[c.id,c]));
    for(const c of current){
      const old=initial.get(c.id);
      if(!old)continue;
      const patch={};
      for(const k of ['name','preference','is_private','sort_order'])if(c[k]!==old[k])patch[k]=c[k];
      if(Object.keys(patch).length){
        await msg('ROSHELF_CATEGORY_UPDATE',{categoryId:c.id,patch});
        Object.assign(old,patch);
        syncCategorySnapshot(snapshot);
      }
    }
    for(const old of snapshot.slice()){
      if(currentIds.has(old.id)||current.some(c=>c.id===old.id))continue;
      await msg('ROSHELF_CATEGORY_DELETE',{categoryId:old.id});
      snapshot=snapshot.filter(c=>c.id!==old.id);
      syncCategorySnapshot(snapshot);
    }
    if(epoch!==categoryEpoch||oauthProfile?.id!==account)return;
    if(revision===categoryRevision){
      categoryRevision=0;
      categoryStatus='Tudo salvo!';
    }else{
      categoryStatus='Novas alteracoes locais pendentes...';
    }
    repaintCategories();
  }catch(e){
    if(epoch!==categoryEpoch||oauthProfile?.id!==account)return;
    if(categoryTimer!==null){clearTimeout(categoryTimer);categoryTimer=null;}
    categoryStatus='Falha ao salvar: '+e.message+'. Sincronizando...';drawEditor();
    try{
      const actual=await msg('ROSHELF_OWNER_LIST');
      if(epoch!==categoryEpoch||oauthProfile?.id!==account)return;
      ownCategories=actual.categories||[];ownLists=toLists(actual);
      if(viewedProfileId()===account)viewData=actual;
      categorySavedSnapshot=cloneCategories(ownCategories);
    }catch(syncError){categoryStatus+=' Falha ao sincronizar: '+syncError.message;}
    categoryRevision++;
    categoryStatus='Erro ao salvar. Confira a lista antes de tentar novamente.';
    repaintCategories();
  }finally{
    categorySending=false;
    if(epoch===categoryEpoch&&oauthProfile?.id===account && categoryRevision!==revision && categoryTimer===null && !categoryStatus.startsWith('Erro')){
      // Se houve nova edicao durante o envio ja iniciado, conclui tambem o estado final.
      queueMicrotask(()=>{if(!categorySending)void flushCategoryJobs()});
    }
  }
}
function changeCategory(kind,body){
  if(!oauthProfile)return;
  if(kind==='ROSHELF_CATEGORY_UPDATE'){
    if(!ownCategories.some(c=>c.id===body.categoryId))return;
    ownCategories=ownCategories.map(c=>c.id===body.categoryId?{...c,...body.patch}:c);
  }else if(kind==='ROSHELF_CATEGORY_DELETE'){
    const ordered=sortedCats();
    const removedIndex=ordered.findIndex(c=>c.id===body.categoryId);
    if(removedIndex>=0 && (ownLists[removedIndex]||[]).length){categoryStatus='Mova os jogos antes de excluir a categoria.';drawEditor();return;}
    if(removedIndex>=0)ownLists.splice(removedIndex,1);
    ownCategories=ownCategories.filter(c=>c.id!==body.categoryId);
    if(current>=ownLists.length)current=Math.max(0,ownLists.length-1);
  }else if(kind==='ROSHELF_CATEGORY_CREATE'){
    if(ownCategories.length>=20){categoryStatus='Limite de 20 categorias.';drawEditor();return;}
    const id='pending-'+crypto.randomUUID();
    ownCategories.push({id,name:body.name,preference:body.preference,is_private:body.isPrivate,legacy_key:null,sort_order:Math.max(-1,...ownCategories.map(c=>Number(c.sort_order)||0))+1});
    ownLists.push([]);
  }
  queueCategorySave();
}
function moveCategory(categoryId,direction){
  if(!oauthProfile)return;
  const ordered=[...ownCategories].sort((a,b)=>Number(a.sort_order)-Number(b.sort_order));
  const from=ordered.findIndex(c=>c.id===categoryId),to=from+direction;
  if(from<0||to<0||to>=ordered.length)return;
  const before=sortedCats();
  const grouped=new Map(before.map((c,i)=>[c.id,ownLists[i]||[]]));
  [ordered[from],ordered[to]]=[ordered[to],ordered[from]];
  ownCategories=ordered.map((c,i)=>({...c,sort_order:i}));
  ownLists=ownCategories.map(c=>grouped.get(c.id)||[]);
  current=ownCategories.findIndex(c=>c.id===before[current]?.id);
  if(current<0)current=0;
  queueCategorySave();
}
function captureCategoryFields(){
  const elements=document.querySelectorAll('#rblxs-editor .rs-category-entry[data-category-id]');
  let changed=false;
  for(const line of elements){
    const cat=ownCategories.find(c=>c.id===line.dataset.categoryId);
    if(!cat)continue;
    const name=line.querySelector('input.rs-input')?.value.trim();
    const pref=Number(line.querySelector('select.rs-input')?.value);
    const is_private=Boolean(line.querySelector('input[type="checkbox"]')?.checked);
    if(!name||name.length>60||!Number.isInteger(pref)||pref<1||pref>5)continue;
    if(cat.name!==name||cat.preference!==pref||cat.is_private!==is_private){
      Object.assign(cat,{name,preference:pref,is_private});changed=true;
    }
  }
  if(changed)queueCategorySave();
}
function exitCategories(){
  captureCategoryFields();
  categoriesOpen=false;
  if(categoryRevision>0&&!categorySending){void flushCategoryJobs();}
}
function manageCategories(panel){
  const heading=el('div','rs-header');heading.append(el('h2','','Gerenciar categorias'),btn('← Voltar',()=>{exitCategories();drawEditor()}));panel.append(heading);
  panel.append(el('p','rs-muted','Altere nomes, notas, privacidade e ordem. Categorias com jogos não podem ser excluídas até os jogos serem movidos.'));
  if(categoryStatus)panel.append(el('p','rs-status',categoryStatus));
  const wrap=el('div','rs-category-list');panel.append(wrap);
  for(const cat of ownCategories){
    const line=el('div','rs-category-entry');line.dataset.categoryId=cat.id;
    const name=el('input','rs-input');name.maxLength=60;name.value=cat.name;name.title='Nome da categoria';
    const pref=el('select','rs-input');pref.title='Preferência';
    for(let i=1;i<=5;i++){const opt=el('option','','Preferência '+i+'/5');opt.value=String(i);pref.append(opt)}pref.value=String(cat.preference);
    const privacy=el('label','rs-cat-private');const ck=el('input');ck.type='checkbox';ck.checked=cat.is_private;privacy.append(ck,el('span','', 'Privada'));
    const actions=el('div','rs-cat-actions');
    const save=btn('Salvar',()=>changeCategory('ROSHELF_CATEGORY_UPDATE',{categoryId:cat.id,patch:{name:name.value.trim(),preference:Number(pref.value),is_private:ck.checked}}));
    const up=btn('↑',()=>moveCategory(cat.id,-1));
    const down=btn('↓',()=>moveCategory(cat.id,1));
    const del=btn('Excluir',()=>{if(confirm('Excluir a categoria '+cat.name+'? Só será permitido se estiver vazia.'))changeCategory('ROSHELF_CATEGORY_DELETE',{categoryId:cat.id})},'rs-btn rs-danger');
    up.disabled=cat.id===ownCategories[0]?.id;
    down.disabled=cat.id===ownCategories[ownCategories.length-1]?.id;
    actions.append(save,up,down,del);line.append(name,pref,privacy,actions);wrap.append(line);
  }
  const add=el('div','rs-category-entry');add.append(el('strong','','Criar nova categoria'));
  const name=el('input','rs-input');name.maxLength=60;name.placeholder='Nome da nova categoria';add.append(name);
  const pref=el('select','rs-input');for(let i=1;i<=5;i++){const op=el('option','','Preferência '+i+'/5');op.value=String(i);pref.append(op)}pref.value='3';add.append(pref);
  const priv=el('label','rs-cat-private');const check=el('input');check.type='checkbox';priv.append(check,el('span','','Privada'));add.append(priv);
  const create=btn('+ Criar categoria',()=>{if(!name.value.trim())return;changeCategory('ROSHELF_CATEGORY_CREATE',{name:name.value.trim(),preference:Number(pref.value),isPrivate:check.checked})});add.append(create);wrap.append(add);
  panel.append(el('p','rs-muted rs-small','As categorias novas recebem jogos pelo editor de jogos. Feche as configurações para sincronizar a categoria antes de adicionar.'));
}
function openEditor(){modal=true;refreshLocalCount();drawEditor()}
function closeEditor(){if(categoriesOpen)exitCategories();void commitGameEdits();modal=false;document.getElementById('rblxs-overlay')?.remove()}
// As mudancas de jogos sao armazenadas no service worker antes de mostrar sucesso local.
// O worker guarda rascunhos em chrome.storage.local e conclui o envio ao sair da edicao.
let gameStageBusy=false;
async function stageGame(kind,g){
  if(gameStageBusy||!oauthProfile)return;
  if(kind==='add' && isPendingId(sortedCats()[current]?.id)){searchStatus='A categoria ainda está sendo salva. Aguarde a confirmação e tente adicionar novamente.';drawEditor();return;}
  gameStageBusy=true;
  try{
    const payload=kind==='add'
      ? {op:'add',category:sortedCats()[current]?.legacy_key||'posso_testar',category_id:sortedCats()[current]?.id,game:{universe_id:String(g.id),place_id:g.placeId||null,game_name:g.name,image_url:g.image||null}}
      : {op:'remove',universe_id:String(g.id)};
    await msg('ROSHELF_STAGE_GAME',{ownerId:oauthProfile.id,change:payload});
    // Optimistic state AFTER durable local staging. No Supabase call yet.
    for(const group of ownLists){const at=group.findIndex(x=>x.id===String(g.id));if(at>=0)group.splice(at,1)}
    if(kind==='add'){if(!ownLists[current])ownLists[current]=[];ownLists[current].push({...g});}
    ownLoaded=true;
    searchStatus='Alteracoes locais pendentes. Troque de lista ou feche o RoShelf para salvar.';
    // Reflete os jogos temporarios somente na propria visualizacao.
    if(viewedProfileId()===oauthProfile.id&&viewData){
      const previous=(viewData.games||[]).filter(x=>String(x.universe_id)!==String(g.id));
      if(kind==='add')previous.push({universe_id:String(g.id),place_id:g.placeId||null,game_name:g.name,image_url:g.image||null,category:sortedCats()[current]?.legacy_key||'posso_testar',category_id:sortedCats()[current]?.id||null});
      viewData={...viewData,games:previous};refreshProfile();
    }
  }catch(e){searchStatus='Nao foi possivel guardar a alteracao: '+e.message}
  finally{gameStageBusy=false;drawEditor()}
}
async function stageLayout(){
  if(!oauthProfile)return;
  const cats=sortedCats();
  await msg('ROSHELF_STAGE_LAYOUT',{ownerId:oauthProfile.id,lists:cats.map((c,i)=>({category_id:c.id,games:(ownLists[i]||[]).map(g=>String(g.id))}))});
}
async function moveGameTo(gameId,targetIndex,beforeId=null){
  const from=ownLists.findIndex(group=>group.some(g=>String(g.id)===String(gameId)));
  if(from<0||!ownLists[targetIndex])return;
  const old=ownLists.map(group=>group.slice());
  const [game]=ownLists[from].splice(ownLists[from].findIndex(g=>String(g.id)===String(gameId)),1);
  const position=beforeId?ownLists[targetIndex].findIndex(g=>String(g.id)===String(beforeId)):-1;
  ownLists[targetIndex].splice(position<0?ownLists[targetIndex].length:position,0,game);
  if(viewedProfileId()===oauthProfile?.id&&viewData){
    const target=sortedCats()[targetIndex];
    viewData={...viewData,games:(viewData.games||[]).map(x=>String(x.universe_id)===String(gameId)?{...x,category_id:target.id,category:target.legacy_key||'posso_testar'}:x)};
    refreshProfile();
  }
  drawEditor();
  try{await stageLayout();searchStatus='Organização pendente. Troque de categoria ou feche o editor para salvar.';}
  catch(e){ownLists=old;searchStatus='Falha ao guardar organização: '+e.message;}
  drawEditor();
}
function showMovePicker(g){
  const cats=sortedCats();
  const choices=cats.map((c,i)=>`${i+1}. ${c.name}`).join('\n');
  const selected=prompt(`Mover ${g.name} para qual categoria?\n${choices}\n\nDigite o número:`,String(current+1));
  if(selected===null)return;
  const index=Number(selected)-1;
  if(!Number.isInteger(index)||index<0||index>=cats.length){searchStatus='Selecione um número de categoria válido.';drawEditor();return;}
  void moveGameTo(g.id,index);
}
function addGame(g){return stageGame('add',g)}
function removeGame(g){return stageGame('remove',g)}
function commitGameEdits(){
  if(!oauthProfile)return Promise.resolve();
  // O service worker continua operando mesmo depois que o editor fecha.
  return msg('ROSHELF_COMMIT_GAMES',{ownerId:oauthProfile.id}).then(()=>{
    // Nao recuperar listas enquanto houver um rascunho mais novo aberto.
  }).catch(e=>{searchStatus='Falha ao sincronizar jogos: '+e.message;drawEditor()});
}
async function importLocal(){if(!oauthProfile||busy||!localCount)return;if(!confirm(`Importar ${localCount} jogo(s) locais para sua conta Roblox? Jogos já presentes serão movidos para a categoria correspondente.`))return;busy=true;searchStatus='Importando jogos locais. Aguarde...';drawEditor();try{const ans=await msg('ROSHELF_IMPORT_LOCAL');searchStatus=`Importação concluída: ${ans.added} salvo(s), ${ans.failed} falha(s).`;await fetchOwn()}catch(e){notifyError(e)}finally{busy=false;drawEditor()}}
async function runSearch(q){if(!q||busy)return;searchQuery=q;searchStatus='Pesquisando...';searchResults=[];drawEditor();try{const res=await msg('RS_FIND_GAME',{query:q});searchResults=res.games||[];searchStatus=searchResults.length?`${searchResults.length} resultado(s)`:'Nenhum jogo encontrado.'}catch(e){searchStatus=e.message}drawEditor()}
function drawEditor(){if(!modal)return;let overlay=document.getElementById('rblxs-overlay');if(!overlay){overlay=el('div');overlay.id='rblxs-overlay';overlay.addEventListener('click',e=>{if(e.target===overlay)closeEditor()});app.append(overlay)}clear(overlay);const panel=el('section');panel.id='rblxs-editor';panel.setAttribute('role','dialog');panel.setAttribute('aria-modal','true');overlay.append(panel);const header=el('div','rs-header');header.append(el('h2','','RoShelf'),btn('Fechar ×',closeEditor));panel.append(header,authPane());if(oauthProfile){const manage=btn(categoriesOpen?'Visualizar jogos':'⚙ Categorias',()=>{if(categoriesOpen)exitCategories();else categoriesOpen=true;drawEditor()});panel.append(manage);if(categoriesOpen){manageCategories(panel);return}}
if(!oauthProfile){panel.append(el('p','rs-muted','Conecte sua conta Roblox para acessar e editar sua lista online.'));if(searchStatus)panel.append(el('p','rs-status',searchStatus));const info=el('div','rs-redirect-info');info.append(el('div','rs-muted rs-small','URL única do RoShelf: só precisa ser cadastrada uma vez pelo responsável pelo app.'));const field=el('input','rs-redirect-input');field.readOnly=true;field.setAttribute('aria-label','Redirect URL fixa do RoShelf');field.placeholder='Carregando URL de retorno...';info.append(field);const copy=btn('Copiar URL fixa',async()=>{try{await navigator.clipboard.writeText(field.value);copy.textContent='Copiado!'}catch{field.focus();field.select()}},'rs-btn');copy.disabled=true;info.append(copy);panel.append(info);msg('ROSHELF_REDIRECT').then(x=>{if(!field.isConnected)return;field.value=x.url||'';copy.disabled=!field.value}).catch(e=>{if(field.isConnected)field.placeholder='Erro ao obter URL: '+e.message});return}
if(current>=ownLists.length)current=0;
if(ownCategories.length && ownLists.length<ownCategories.length){while(ownLists.length<ownCategories.length)ownLists.push([]);}
if(!ownLoaded)panel.append(el('p','rs-muted','Carregando seus jogos do servidor...'));
const featuredTip=el('div','rs-featured-tip',`★ Destaques opcionais: ${featuredIds.length}/3 · Abra uma categoria e clique em ☆ Destacar abaixo da capa de um jogo.`);panel.append(featuredTip);
if(localCount){const copy=el('div','rs-import');copy.append(el('span','rs-muted',`${localCount} jogo(s) encontrados na versão local anterior.`));const b=btn(busy?'Aguarde...':'Importar jogos locais',importLocal);b.disabled=busy;copy.append(b);panel.append(copy)}
const layout=el('div','rs-layout');panel.append(layout);tabItems(layout,current,i=>{if(i===current)return;void commitGameEdits();current=i;searchResults=[];searchStatus='';drawEditor()});const right=el('div');layout.append(right);right.append(el('h3','',selectedCategory(current)));const search=el('div','rs-search');const inp=el('input','rs-input');inp.placeholder='Pesquisar jogo ou colar link do Roblox';inp.value=searchQuery;inp.setAttribute('aria-label','Pesquisar');inp.addEventListener('keydown',e=>{if(e.key==='Enter')runSearch(inp.value.trim())});search.append(inp);const searchButton=btn('Pesquisar',()=>runSearch(inp.value.trim()));searchButton.disabled=busy;search.append(searchButton);right.append(search);right.append(el('div','rs-status',searchStatus||'Pesquise um jogo para adicioná-lo nesta categoria.'));
for(const g of searchResults){const row=el('div','rs-result');const img=el('img');img.src=imageUrl(g)||'';img.alt='';row.append(img);const main=el('div','rs-result-main');main.append(el('strong','',g.name));const inCat=ownLists.findIndex(a=>a.some(x=>x.id===g.id));if(inCat>=0)main.append(el('span','rs-muted rs-small',`Atualmente: ${selectedCategory(inCat)}`));row.append(main);const b=btn(inCat===current?'Já adicionado':inCat>=0?'Mover para cá':'Adicionar',()=>addGame(g));b.disabled=busy||inCat===current;row.append(b);right.append(row)}
right.append(el('h3','',`Nesta categoria (${(ownLists[current]||[]).length})`));const grid=el('div','rs-gamegrid');(ownLists[current]||[]).forEach(g=>grid.append(gameCard(g,true)));right.append(grid);if(!(ownLists[current]||[]).length)right.append(el('div','rs-status','Nenhum jogo nesta categoria.'))}
// RoShelf 0.13: opt-in, ordered featured podium. No new OAuth scopes or API actions.
function featureLibrary(){
  const result=new Map();
  for(const g of viewData?.games||[]){
    const id=String(g.universe_id||'');
    if(id)result.set(id,{id,placeId:g.place_id?String(g.place_id):'',name:g.game_name||'Jogo',image:g.image_url||'',categoryId:g.category_id||''});
  }
  // Include locally staged games, including those not yet committed to Supabase.
  for(let i=0;i<ownLists.length;i++)for(const g of ownLists[i]||[]){
    const id=String(g.id||'');
    if(id)result.set(id,{...result.get(id),id,placeId:g.placeId||'',name:g.name||'Jogo',image:g.image||'',categoryId:sortedCats()[i]?.id||''});
  }
  return result;
}
function setFeaturedDraft(next){
  if(!featuredEditing||featuredSaving)return;
  featuredDraft=[...next];featuredEditError='';refreshProfile();
}
function pickFeatured(id){
  if(!featuredEditing||featuredSaving)return;
  id=String(id);
  if(featuredDraft.includes(id))setFeaturedDraft(featuredDraft.filter(x=>x!==id));
  else if(featuredDraft.length<3)setFeaturedDraft([...featuredDraft,id]);
  else {featuredEditError='O limite é de três jogos. Remova um destaque primeiro.';refreshProfile();}
}
function reorderFeatured(from,to){
  if(!featuredEditing||featuredSaving||from===to||from<0||to<0||from>=featuredDraft.length||to>=featuredDraft.length)return;
  const next=[...featuredDraft];const [item]=next.splice(from,1);next.splice(to,0,item);setFeaturedDraft(next);
}
function beginFeaturedEdit(){
  if(!isOwn()||featuredSaving)return;
  featuredEditing=true;featuredDraft=[...featuredIds];featuredEditError='';featuredPickerQuery='';refreshProfile();
}
async function finishFeaturedEdit(){
  if(!featuredEditing||featuredSaving||!isOwn())return;
  const desired=[...featuredDraft];
  if(JSON.stringify(desired)===JSON.stringify(featuredIds)){
    featuredEditing=false;featuredEditError='';refreshProfile();return;
  }
  featuredSaving=true;featuredEditError='';refreshProfile();
  try{
    // The same API operation used by the existing star buttons; no server change.
    await msg('ROSHELF_COMMIT_GAMES',{ownerId:oauthProfile.id});
    await msg('ROSHELF_FEATURED_SET',{games:desired});
    featuredIds=[...desired];
    if(viewData && viewingId===oauthProfile.id){
      const positions=new Map(desired.map((id,i)=>[id,i+1]));
      viewData={...viewData,games:(viewData.games||[]).map(g=>({...g,featured_position:positions.get(String(g.universe_id))??null}))};
    }
    featuredEditing=false;featuredEditError='';
  }catch(e){
    // Keep the unsaved draft on screen; do not claim it was saved.
    featuredEditError='Não foi possível salvar os destaques: '+String(e?.message||e)+'. Tente novamente.';
  }finally{featuredSaving=false;refreshProfile();}
}
function featureCover(game){
  const wrapper=el('div','rs-featured-cover');
  const url=imageUrl(game);
  if(url){const img=el('img');img.src=url;img.alt='Capa de '+game.name;img.loading='lazy';img.draggable=false;wrapper.append(img)}
  else wrapper.append(el('span','rs-featured-fallback','★'));
  return wrapper;
}
function featureCard(game,i,canEdit){
  const card=el('div','rs-featured-card '+(i===0?'rs-featured-lead':`rs-featured-runner rs-featured-runner-${i+1}`));
  const linkUrl=gameUrl(game);
  const body=canEdit?el('div','rs-featured-card-link'):el(linkUrl?'a':'div','rs-featured-card-link');
  if(!canEdit&&linkUrl){body.href=linkUrl;body.target='_blank';body.rel='noopener noreferrer'}
  body.append(featureCover(game));
  const info=el('div','rs-featured-details');
  info.append(el('div','rs-featured-rank',i===0?'★ #1 · Favorite Game':`✦ #${i+1} Featured`));
  info.append(el('div','rs-featured-name',game.name));
  body.append(info);card.append(body);
  if(canEdit){
    card.draggable=true;
    card.title='Arraste para alterar a ordem dos destaques';
    card.addEventListener('dragstart',e=>{
      if(featuredSaving)return e.preventDefault();
      featuredDragging=i;e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',String(i));
    });
    card.addEventListener('dragover',e=>{if(featuredDragging!==null){e.preventDefault();card.classList.add('rs-featured-drop')}});
    card.addEventListener('dragleave',()=>card.classList.remove('rs-featured-drop'));
    card.addEventListener('drop',e=>{e.preventDefault();card.classList.remove('rs-featured-drop');if(featuredDragging!==null){const from=featuredDragging;featuredDragging=null;reorderFeatured(from,i)}});
    card.addEventListener('dragend',()=>{featuredDragging=null;card.classList.remove('rs-featured-drop')});
    const actions=el('div','rs-featured-actions');
    const up=btn('↑',()=>reorderFeatured(i,i-1),'rs-featured-action');up.disabled=i===0||featuredSaving;up.title='Subir no Top 3';up.setAttribute('aria-label','Subir '+game.name);
    const down=btn('↓',()=>reorderFeatured(i,i+1),'rs-featured-action');down.disabled=i===featuredDraft.length-1||featuredSaving;down.title='Descer no Top 3';down.setAttribute('aria-label','Descer '+game.name);
    const remove=btn('✕',()=>pickFeatured(game.id),'rs-featured-action');remove.disabled=featuredSaving;remove.title='Remover dos destaques';remove.setAttribute('aria-label','Remover '+game.name+' dos destaques');
    actions.append(up,down,remove);card.append(actions);
  }
  return card;
}
function featuredPickerResults(node){
  clear(node);const games=[...featureLibrary().values()];
  const needle=featuredPickerQuery.trim().toLocaleLowerCase('pt-BR');
  const filtered=needle?games.filter(g=>g.name.toLocaleLowerCase('pt-BR').includes(needle)):games;
  if(!filtered.length){node.append(el('span','rs-featured-picker-empty','Nenhum jogo encontrado na sua biblioteca.'));return}
  for(const g of filtered.slice(0,40)){
    const active=featuredDraft.includes(g.id);
    const button=btn(`${active?'★':'☆'} ${g.name}`,()=>pickFeatured(g.id),'rs-featured-pick'+(active?' rs-featured-chosen':''));
    button.disabled=featuredSaving;button.title=active?'Remover dos destaques':'Adicionar aos destaques';
    node.append(button);
  }
  if(filtered.length>40)node.append(el('span','rs-featured-picker-empty',`Exibindo 40 de ${filtered.length} jogos. Pesquise pelo nome para encontrar outros.`));
}
function buildFeaturedSection(games,owner){
  if(!games.length && !(owner&&featuredEditing))return null;
  const section=el('section','rs-featured-section'+(games.length===1?' rs-featured-one':'')+(featuredEditing&&owner?' rs-featured-editing':''));
  const heading=el('div','rs-featured-heading');
  heading.append(el('strong','', '★ Jogos em destaque'));
  heading.append(el('span','rs-featured-count',`${games.length}/3 jogos`));
  section.append(heading);
  if(games.length){
    const podium=el('div','rs-featured-podium');
    podium.append(featureCard(games[0],0,owner&&featuredEditing));
    if(games.length>1){
      const runners=el('div','rs-featured-runners');
      games.slice(1).forEach((g,i)=>runners.append(featureCard(g,i+1,owner&&featuredEditing)));
      podium.append(runners);
    }
    section.append(podium);
  }else section.append(el('div','rs-featured-empty','Nenhum jogo em destaque. Esta seção não aparece para visitantes.'));
  if(owner&&featuredEditing){
    section.append(el('div','rs-featured-instruction','Escolha até 3 jogos e arraste os cartões ou use as setas para definir o Top 3. O primeiro será seu Favorite Game.'));
    const picker=el('div','rs-featured-picker');
    const input=el('input','rs-featured-search');input.type='search';input.placeholder='Pesquisar na sua biblioteca...';input.value=featuredPickerQuery;
    input.setAttribute('aria-label','Pesquisar jogos para destacar');
    const results=el('div','rs-featured-picker-results');
    input.addEventListener('input',()=>{featuredPickerQuery=input.value;featuredPickerResults(results)});
    picker.append(input,results);featuredPickerResults(results);section.append(picker);
    if(featuredEditError)section.append(el('div','rs-featured-error',featuredEditError));
    const foot=el('div','rs-featured-edit-footer');
    foot.append(el('span','',featuredSaving?'Salvando alterações...':'As mudanças são salvas ao concluir a edição.'));
    const cancel=btn('Cancelar',()=>{if(featuredSaving)return;featuredEditing=false;featuredEditError='';refreshProfile()},'rs-featured-secondary');
    cancel.disabled=featuredSaving;
    const save=btn(featuredSaving?'Salvando...':'✓ Concluir edição',()=>void finishFeaturedEdit(),'rs-featured-save');save.disabled=featuredSaving;
    foot.append(cancel,save);section.append(foot);
  }
  return section;
}
// RoShelf 0.13.1: busca global local. Nunca requisita categorias privadas de visitantes.
// A API publica filtra as categorias antes de enviar os dados para a extensao.
const rsSearchText=value=>String(value??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('pt-BR');
function profileSearchEntries(data){
  const cats=(data?.categories||[]).slice().sort((a,b)=>Number(a.sort_order)-Number(b.sort_order));
  const fallbacks=cats.length?cats:KEYS.map((key,i)=>({id:'legacy:'+i,legacy_key:key,name:CATS[i],sort_order:i}));
  const byId=new Map(cats.map(c=>[String(c.id),c]));
  const byLegacy=new Map(fallbacks.filter(c=>c.legacy_key).map(c=>[String(c.legacy_key),c]));
  const rows=[];
  for(const g of data?.games||[]){
    const cat=g.category_id?byId.get(String(g.category_id)):byLegacy.get(String(g.category));
    // Dados sem categoria publica explicitamente presente nao entram na busca.
    if(!cat || !g.universe_id)continue;
    rows.push({id:String(g.universe_id),placeId:g.place_id?String(g.place_id):'',name:String(g.game_name||'Jogo'),image:g.image_url||'',
      categoryId:String(cat.id),categoryName:String(cat.name||'Categoria'),categoryPrivate:Boolean(cat.is_private),
      categoryOrder:Number(cat.sort_order)||0,gameOrder:Number(g.sort_order)||0,
      addedAt:typeof g.created_at==='string'?Date.parse(g.created_at):NaN});
  }
  return {categories:fallbacks,rows};
}
function filterProfileSearch(entries, query, categoryId, sort){
  const needle=rsSearchText(query.trim());
  const out=entries.filter(g=>(categoryId==='all'||g.categoryId===categoryId)&&(!needle||rsSearchText(g.name).includes(needle)));
  const names=(a,b)=>a.name.localeCompare(b.name,'pt-BR',{sensitivity:'base'});
  const custom=(a,b)=>(a.categoryOrder-b.categoryOrder)||(a.gameOrder-b.gameOrder)||names(a,b);
  if(sort==='az')out.sort(names);
  else if(sort==='za')out.sort((a,b)=>names(b,a));
  else if(sort==='recent'||sort==='old'){
    const direction=sort==='recent'?-1:1;
    out.sort((a,b)=>direction*(a.addedAt-b.addedAt)||custom(a,b));
  }else out.sort(custom);
  return out;
}
function buildProfileSearchPanel(data){
  const {categories,rows}=profileSearchEntries(data);
  const panel=el('div','rs-profile-search-panel');
  const tools=el('div','rs-profile-search-tools');
  const field=el('input','rs-profile-search-input');field.id='rblxs-profile-search-input';
  field.type='search';field.placeholder='Pesquisar jogos na biblioteca inteira...';field.setAttribute('aria-label','Pesquisar jogos no perfil');
  field.autocomplete='off';field.maxLength=120;field.value=profileSearchQuery;
  const category=el('select','rs-profile-search-select');category.setAttribute('aria-label','Filtrar por categoria');
  const all=el('option','','Todas as categorias');all.value='all';category.append(all);
  for(const c of categories){const opt=el('option','',c.name+(c.is_private?' 🔒':''));opt.value=String(c.id);category.append(opt)}
  if(profileSearchCategory!=='all'&&!categories.some(c=>String(c.id)===profileSearchCategory))profileSearchCategory='all';
  category.value=profileSearchCategory;
  const sort=el('select','rs-profile-search-select');sort.setAttribute('aria-label','Ordenar resultados');
  const hasDates=rows.length>0&&rows.every(g=>Number.isFinite(g.addedAt));
  const options=[['custom','Ordem personalizada'],['az','Nome A–Z'],['za','Nome Z–A'],['recent','Mais recentes'],['old','Mais antigos']];
  for(const [id,label] of options){const opt=el('option','',label);opt.value=id;if((id==='recent'||id==='old')&&!hasDates){opt.disabled=true;opt.title='Data de inclusão não disponível nesta lista'}sort.append(opt)}
  if(!hasDates&&(profileSearchSort==='recent'||profileSearchSort==='old'))profileSearchSort='custom';
  sort.value=profileSearchSort;
  tools.append(field,category,sort);panel.append(tools);
  const resultMeta=el('div','rs-profile-search-meta');panel.append(resultMeta);
  const grid=el('div','rs-profile-search-results');panel.append(grid);
  const render=()=>{
    clear(grid);
    if(viewLoading){resultMeta.textContent='Carregando lista...';return}
    if(viewError){resultMeta.textContent='Erro ao carregar: '+viewError;return}
    const matches=filterProfileSearch(rows,profileSearchQuery,profileSearchCategory,profileSearchSort);
    const showing=matches.slice(0,120);
    resultMeta.textContent=`${matches.length} ${matches.length===1?'jogo encontrado':'jogos encontrados'}${matches.length>120?' · Exibindo os primeiros 120; refine sua pesquisa.':''}`;
    if(!matches.length){grid.append(el('p','rs-profile-search-empty',profileSearchQuery?'Nenhum jogo encontrado.':'Nenhum jogo nesta seleção.'));return}
    const fragment=document.createDocumentFragment();
    for(const g of showing){
      const item=el('div','rs-profile-search-result');
      const url=gameUrl(g);
      const link=el(url?'a':'div','rs-profile-search-link');
      if(url){link.href=url;link.target='_blank';link.rel='noopener noreferrer'}
      const cover=el('img');cover.src=imageUrl(g)||'';cover.alt='';cover.loading='lazy';
      const name=el('span','rs-profile-search-name',g.name);
      const label=el('span','rs-profile-search-category',`${g.categoryPrivate?'🔒 ':''}${g.categoryName}`);
      link.append(cover,name,label);item.append(link);fragment.append(item);
    }
    grid.append(fragment);
  };
  field.addEventListener('input',()=>{profileSearchQuery=field.value;render()});
  category.addEventListener('change',()=>{profileSearchCategory=category.value;render()});
  sort.addEventListener('change',()=>{profileSearchSort=sort.value;render()});
  if(!hasDates){const note=el('div','rs-profile-search-note','Ordenação por data indisponível: a API deste perfil não envia datas de inclusão.');panel.append(note)}
  render();return panel;
}
// RoShelf 0.13.2 — estatísticas calculadas localmente, somente com os dados
// já autorizados pela API. Dono recebe owner_list; visitante recebe GET público.
let statsReturnFocus=null;
function closeProfileStats(){
  const overlay=document.getElementById('rblxs-stats-overlay');
  if(!overlay)return;
  overlay.remove();
  if(statsReturnFocus?.isConnected)statsReturnFocus.focus();
  statsReturnFocus=null;
}
function statsLineChart(container,label,count,max,extra=''){
  const row=el('div','rs-stats-chart-line');
  const head=el('div','rs-stats-chart-line-head');
  head.append(el('span','rs-stats-chart-label',label),el('span','rs-stats-chart-amount',String(count)+extra));
  const track=el('div','rs-stats-chart-track');
  const bar=el('div','rs-stats-chart-fill');
  bar.style.width=(max>0?Math.round((count/max)*100):0)+'%';
  track.append(bar);row.append(head,track);container.append(row);
}
function statsMetric(label,value){
  const card=el('div','rs-stats-metric');
  card.append(el('strong','rs-stats-metric-value',String(value)),el('span','rs-stats-metric-label',label));
  return card;
}
function openProfileStats(trigger){
  if(document.getElementById('rblxs-stats-overlay')){closeProfileStats();return}
  statsReturnFocus=trigger||document.activeElement;
  const owner=isOwn();
  const overlay=el('div','rs-stats-overlay');overlay.id='rblxs-stats-overlay';
  const dialog=el('section','rs-stats-dialog');dialog.setAttribute('role','dialog');dialog.setAttribute('aria-modal','true');
  dialog.setAttribute('aria-labelledby','rblxs-stats-title');
  const header=el('div','rs-stats-header');
  const heading=el('div','rs-stats-heading');
  const h=el('h2','','Estatísticas do RoShelf');h.id='rblxs-stats-title';
  heading.append(h,el('p','',owner?'Visão da sua biblioteca, incluindo categorias privadas.':'Somente informações públicas deste perfil.'));
  const close=btn('✕ Fechar',closeProfileStats,'rs-stats-close');
  header.append(heading,close);dialog.append(header);
  if(viewLoading||!viewData){
    dialog.append(el('p','rs-stats-empty',viewError?'Não foi possível carregar a biblioteca.':'Carregando estatísticas...'));
  }else{
    const entries=profileSearchEntries(viewData);
    // Sem nenhuma categoria salva e sem jogos, nao inventar 6 categorias no placar.
    const categories=(!viewData.categories?.length && !viewData.games?.length)?[]:entries.categories;
    const rows=entries.rows;
    const counts=new Map(categories.map(c=>[String(c.id),0]));
    const distribution=[0,0,0,0,0];
    const categoryMap=new Map(categories.map(c=>[String(c.id),c]));
    let weighted=0,scored=0,featured=0;
    for(const game of rows){
      counts.set(game.categoryId,(counts.get(game.categoryId)||0)+1);
      const category=categoryMap.get(game.categoryId);
      const score=Number(category?.preference);
      if(Number.isInteger(score)&&score>=1&&score<=5){distribution[score-1]++;weighted+=score;scored++}
    }
    // Só são considerados os destaques dos jogos permitidos nesta resposta.
    const visibleIds=new Set(rows.map(g=>g.id));
    const marked=(viewData.games||[]).filter(g=>visibleIds.has(String(g.universe_id))&&Number.isInteger(Number(g.featured_position))&&Number(g.featured_position)>=1&&Number(g.featured_position)<=3);
    featured=marked.length;
    const intro=el('div','rs-stats-metrics');
    intro.append(statsMetric('Jogos',rows.length),statsMetric('Categorias',categories.length),statsMetric('Destaques',featured));
    dialog.append(intro);
    const body=el('div','rs-stats-body');
    const categorySection=el('section','rs-stats-section');
    categorySection.append(el('h3','','Jogos por categoria'));
    if(!categories.length){categorySection.append(el('p','rs-stats-empty','Nenhuma categoria disponível.'))}
    else{
      const sorted=categories.map(c=>({cat:c,count:counts.get(String(c.id))||0})).sort((a,b)=>b.count-a.count||Number(a.cat.sort_order)-Number(b.cat.sort_order));
      const max=Math.max(1,...sorted.map(x=>x.count));
      const chart=el('div','rs-stats-chart rs-stats-categories');
      for(const x of sorted){
        statsLineChart(chart,String(x.cat.name||'Categoria')+(owner&&x.cat.is_private?' 🔒':''),x.count,max);
      }
      categorySection.append(chart);
    }
    const prefSection=el('section','rs-stats-section');
    prefSection.append(el('h3','','Distribuição por preferência'));
    if(scored){
      const badge=el('p','rs-stats-subtitle',`Preferência média dos jogos: ${(weighted/scored).toFixed(1).replace('.',',')}/5`);
      prefSection.append(badge);
      const chart=el('div','rs-stats-chart');
      const max=Math.max(1,...distribution);
      for(let score=5;score>=1;score--)statsLineChart(chart,`${score}/5`,distribution[score-1],max);
      prefSection.append(chart);
      prefSection.append(el('p','rs-stats-footnote','A preferência é definida pela categoria. A média considera o número de jogos em cada nota.'));
    }else prefSection.append(el('p','rs-stats-empty','Nenhum jogo com nota de preferência disponível.'));
    body.append(categorySection,prefSection);
    const dated=rows.filter(g=>Number.isFinite(g.addedAt)).sort((a,b)=>b.addedAt-a.addedAt);
    if(dated.length){
      const recent=el('section','rs-stats-section rs-stats-recent');
      recent.append(el('h3','','Adicionados recentemente'));
      const list=el('div','rs-stats-recent-list');
      for(const game of dated.slice(0,5)){
        const item=el('div','rs-stats-recent-item');
        const title=el('span','rs-stats-recent-name',game.name);
        const date=el('span','rs-stats-recent-date',new Date(game.addedAt).toLocaleDateString('pt-BR'));
        item.append(title,date);list.append(item);
      }
      recent.append(list);body.append(recent);
    }
    dialog.append(body);
    const footer=el('div','rs-stats-footer',owner?'Estatísticas calculadas na extensão, usando sua biblioteca autorizada.':'Categorias privadas não são incluídas nas estatísticas públicas.');
    dialog.append(footer);
  }
  overlay.append(dialog);overlay.addEventListener('click',e=>{if(e.target===overlay)closeProfileStats()});
  app.append(overlay);close.focus();
}
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&document.getElementById('rblxs-stats-overlay')){e.preventDefault();closeProfileStats()}});
// RoShelf 0.13.3 — comparação local entre DUAS listas publicas.
// Buscar a propria lista pelo GET publico evita comparar ou revelar categorias privadas.
let compareReturnFocus=null,compareEpoch=0;
function closeProfileCompare(){
  compareEpoch++;
  const overlay=document.getElementById('rblxs-compare-overlay');
  if(overlay)overlay.remove();
  if(compareReturnFocus?.isConnected)compareReturnFocus.focus();
  compareReturnFocus=null;
}
function compareEntries(data){
  const prepared=profileSearchEntries(data);
  const categories=new Map(prepared.categories.map(c=>[String(c.id),c]));
  const mapped=new Map();
  for(const game of prepared.rows){
    // Defense in depth: nao comparar categorias privadas mesmo se uma API desatualizada as enviar.
    if(game.categoryPrivate)continue;
    const category=categories.get(game.categoryId);
    const raw=Number(category?.preference);
    const score=Number.isInteger(raw)&&raw>=1&&raw<=5?raw:null;
    mapped.set(game.id,{...game,preference:score});
  }
  return mapped;
}
function calculateComparison(myData,theirData){
  const mine=compareEntries(myData),theirs=compareEntries(theirData);
  const common=[],onlyMine=[],onlyTheirs=[];
  for(const [id,myGame] of mine){
    const other=theirs.get(id);
    if(!other){onlyMine.push(myGame);continue}
    const valid=myGame.preference!==null&&other.preference!==null;
    const score=valid?Math.round((1-Math.abs(myGame.preference-other.preference)/4)*100):null;
    common.push({id,name:other.name||myGame.name,placeId:other.placeId||myGame.placeId,
      image:other.image||myGame.image,mine:myGame,other,score});
  }
  for(const [id,game] of theirs)if(!mine.has(id))onlyTheirs.push(game);
  const scored=common.filter(g=>g.score!==null);
  const percentage=scored.length?Math.round(scored.reduce((n,g)=>n+g.score,0)/scored.length):null;
  return {common,onlyMine,onlyTheirs,percentage,scoredCount:scored.length,
    myCount:mine.size,theirCount:theirs.size};
}
async function openProfileCompare(trigger){
  if(!oauthProfile || viewedProfileId()===oauthProfile.id || !viewData || !viewData.exists)return;
  closeProfileCompare();
  compareReturnFocus=trigger||document.activeElement;
  const myId=String(oauthProfile.id),otherId=viewedProfileId();
  const expected=compareEpoch;
  const overlay=el('div','rs-compare-overlay');overlay.id='rblxs-compare-overlay';
  const dialog=el('section','rs-compare-dialog');dialog.setAttribute('role','dialog');dialog.setAttribute('aria-modal','true');
  dialog.setAttribute('aria-labelledby','rblxs-compare-title');
  const header=el('div','rs-compare-header');
  const heading=el('div','rs-compare-heading');
  const title=el('h2','','Comparar listas');title.id='rblxs-compare-title';
  heading.append(title,el('p','','Semelhança de opiniões · apenas jogos e categorias públicos.'));
  const close=btn('✕ Fechar',closeProfileCompare,'rs-compare-close');
  header.append(heading,close);dialog.append(header);
  const body=el('div','rs-compare-body');body.append(el('p','rs-compare-loading','Carregando sua biblioteca pública...'));
  dialog.append(body);overlay.append(dialog);
  overlay.addEventListener('click',e=>{if(e.target===overlay)closeProfileCompare()});
  app.append(overlay);close.focus();
  try{
    const mine=await msg('ROSHELF_GET_LIST',{userId:myId});
    if(compareEpoch!==expected || !overlay.isConnected || viewedProfileId()!==otherId || oauthProfile?.id!==myId)return;
    if(!mine.exists){clear(body);body.append(el('p','rs-compare-loading','Sua conta ainda não tem uma lista RoShelf pública para comparar.'));return}
    // viewData foi carregada usando GET publico, pois este e um perfil alheio.
    const result=calculateComparison(mine,viewData);
    const theirName=String(viewData.profile?.display_name||viewData.profile?.username||'Outra pessoa');
    const myName=String(mine.profile?.display_name||mine.profile?.username||'Você');
    clear(body);
    const summary=el('div','rs-compare-summary');
    const scoreBox=el('div','rs-compare-score');
    scoreBox.append(el('span','rs-compare-superlabel','Compatibilidade de opiniões'));
    scoreBox.append(el('strong','rs-compare-percent',result.percentage===null?'—':`${result.percentage}%`));
    scoreBox.append(el('span','rs-compare-score-note',result.scoredCount?
      `${result.scoredCount} ${result.scoredCount===1?'jogo avaliado':'jogos avaliados'} em comum`:
      'Sem jogos públicos com notas válidas em comum'));
    summary.append(scoreBox);
    const stats=el('div','rs-compare-stats');
    for(const [label,value] of [['Jogos em comum',result.common.length],['Só na sua lista',result.onlyMine.length],['Só na outra lista',result.onlyTheirs.length]]){
      const tile=el('div','rs-compare-stat');tile.append(el('strong','',String(value)),el('span','',label));stats.append(tile);
    }
    summary.append(stats);body.append(summary);
    if(result.scoredCount>0&&result.scoredCount<5){body.append(el('p','rs-compare-caution',`Atenção: só ${result.scoredCount} ${result.scoredCount===1?'jogo foi comparado':'jogos foram comparados'}. A porcentagem pode não representar bem a afinidade geral.`));}
    const note=el('div','rs-compare-formula',`Cada jogo em comum vale 100% quando as notas são iguais e 0% quando uma pessoa dá 1/5 e a outra 5/5. A nota final é a média dos jogos com notas válidas.`);
    body.append(note);
    const tabs=el('div','rs-compare-tabs');
    const panes=[{id:'common',label:'Em comum',num:result.common.length},{id:'mine',label:'Só meus',num:result.onlyMine.length},{id:'theirs',label:'Só da outra pessoa',num:result.onlyTheirs.length}];
    let selected='common',order='similar',query='';
    const toolRow=el('div','rs-compare-tools');
    const search=el('input','rs-compare-search');search.type='search';search.placeholder='Pesquisar nos resultados...';search.maxLength=120;
    search.setAttribute('aria-label','Pesquisar jogos comparados');
    const sorter=el('select','rs-compare-select');sorter.setAttribute('aria-label','Ordenar comparação');
    for(const [v,label] of [['similar','Mais concordância'],['different','Mais discordância'],['az','Nome A–Z']]){const option=el('option','',label);option.value=v;sorter.append(option)}
    toolRow.append(search,sorter);
    const results=el('div','rs-compare-results');
    const count=el('div','rs-compare-results-count');
    const escapeGameName=game=>game.name||'Jogo';
    function renderResults(){
      clear(tabs);clear(results);
      for(const tab of panes){const t=btn(`${tab.label} (${tab.num})`,()=>{selected=tab.id;renderResults()},'rs-compare-tab');
        t.dataset.active=String(selected===tab.id);tabs.append(t)}
      sorter.disabled=selected!=='common';
      const list=selected==='common'?[...result.common]:selected==='mine'?[...result.onlyMine]:[...result.onlyTheirs];
      const filtered=list.filter(g=>rsSearchText(escapeGameName(g)).includes(rsSearchText(query)));
      if(selected==='common'){
        filtered.sort((a,b)=>{
          if(order==='az')return a.name.localeCompare(b.name,'pt-BR',{sensitivity:'base'});
          const av=a.score===null?-1:a.score,bv=b.score===null?-1:b.score;
          return (order==='different'?av-bv:bv-av)||a.name.localeCompare(b.name,'pt-BR',{sensitivity:'base'});
        });
      }else filtered.sort((a,b)=>a.name.localeCompare(b.name,'pt-BR',{sensitivity:'base'}));
      count.textContent=`${filtered.length} ${filtered.length===1?'jogo':'jogos'}${filtered.length>100?' · Exibindo os primeiros 100':''}`;
      if(!filtered.length){results.append(el('p','rs-compare-empty',query?'Nenhum jogo corresponde à pesquisa.':selected==='common'?'Nenhum jogo público em comum.':'Nenhum jogo nesta seleção.'));return}
      const frag=document.createDocumentFragment();
      for(const g of filtered.slice(0,100)){
        const item=el('div','rs-compare-game');
        const url=gameUrl(g);
        const a=el(url?'a':'div','rs-compare-game-link');
        if(url){a.href=url;a.target='_blank';a.rel='noopener noreferrer'}
        const cover=el('img','');cover.loading='lazy';cover.alt='';cover.src=imageUrl(g)||'';
        a.append(cover,el('span','rs-compare-game-name',escapeGameName(g)));item.append(a);
        const details=el('div','rs-compare-game-details');
        if(selected==='common'){
          const comparison=el('div','rs-compare-judgments');
          const self=el('div','');self.append(el('small','',myName),el('span','',`${g.mine.categoryName} · ${g.mine.preference===null?'Sem nota':g.mine.preference+'/5'}`));
          const other=el('div','');other.append(el('small','',theirName),el('span','',`${g.other.categoryName} · ${g.other.preference===null?'Sem nota':g.other.preference+'/5'}`));
          comparison.append(self,other);details.append(comparison);
          const badge=el('span','rs-compare-agreement',g.score===null?'Sem nota':`${g.score}% de concordância`);
          if(g.score!==null)badge.dataset.level=g.score>=75?'high':g.score<=25?'low':'mid';
          details.append(badge);
        }else details.append(el('span','rs-compare-category',g.categoryName));
        item.append(details);frag.append(item);
      }
      results.append(frag);
    }
    search.addEventListener('input',()=>{query=search.value;renderResults()});
    sorter.addEventListener('change',()=>{order=sorter.value;renderResults()});
    body.append(tabs,toolRow,count,results);
    body.append(el('p','rs-compare-footer','Cálculo local, sem salvar ou compartilhar seu resultado. Categorias privadas de ambas as contas ficam fora desta comparação.'));
    renderResults();
  }catch(e){
    if(compareEpoch===expected&&overlay.isConnected){clear(body);body.append(el('p','rs-compare-error','Não foi possível carregar a comparação: '+String(e.message||e)));}
  }
}
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&document.getElementById('rblxs-compare-overlay')){e.preventDefault();closeProfileCompare()}});

// RoShelf 0.13.4 — importar apenas jogos PUBLICOS de outros perfis.
// A API volta a verificar a privacidade e faz insert-only, sem mover jogos existentes.
let importEpoch=0,importReturnFocus=null,importInFlight=false;
function closeProfileImport(){
  if(importInFlight)return; // keep the result visible while the confirmed import runs
  ++importEpoch;
  document.getElementById('rblxs-import-overlay')?.remove();
  if(importReturnFocus?.isConnected)importReturnFocus.focus();
  importReturnFocus=null;
}
async function openProfileImport(trigger){
  if(!oauthProfile||isOwn()||!viewData?.exists)return;
  if(document.getElementById('rblxs-import-overlay'))return;
  importReturnFocus=trigger||document.activeElement;
  const sourceUserId=viewedProfileId(),ownerId=String(oauthProfile.id),epoch=++importEpoch;
  const overlay=el('div','rs-fimport-overlay');overlay.id='rblxs-import-overlay';
  const dialog=el('section','rs-fimport-dialog');dialog.setAttribute('role','dialog');dialog.setAttribute('aria-modal','true');dialog.setAttribute('aria-labelledby','rblxs-import-title');
  const header=el('div','rs-fimport-header');
  const head=el('div');const title=el('h2','','Importar jogos de outro perfil');title.id='rblxs-import-title';
  head.append(title,el('p','','Selecione jogos públicos e escolha uma categoria da sua biblioteca.'));
  const close=btn('✕ Fechar',closeProfileImport,'rs-fimport-close');header.append(head,close);dialog.append(header);
  const body=el('div','rs-fimport-body');body.append(el('p','rs-fimport-notice','Conferindo jogos públicos e os que você já possui...'));
  dialog.append(body);overlay.append(dialog);app.append(overlay);
  overlay.addEventListener('click',e=>{if(e.target===overlay)closeProfileImport()});
  try{
    // Refresh both sides; do not use an old profile snapshot for privacy.
    const [source, mine]=await Promise.all([
      msg('ROSHELF_GET_LIST',{userId:sourceUserId}),msg('ROSHELF_OWNER_LIST')
    ]);
    if(epoch!==importEpoch||!overlay.isConnected||viewedProfileId()!==sourceUserId||String(oauthProfile?.id)!==ownerId)return;
    if(!source.exists){clear(body);body.append(el('p','rs-fimport-notice','Este perfil não tem biblioteca pública.'));return;}
    const sourceEntries=profileSearchEntries(source);
    const publicCategories=sourceEntries.categories.filter(c=>!c.is_private);
    const sourceRows=[...new Map(sourceEntries.rows.filter(g=>!g.categoryPrivate).map(g=>[g.id,g])).values()];
    const owned=new Set([...(mine.games||[]).map(g=>String(g.universe_id)),...ownLists.flat().map(g=>String(g.id))]);
    const destinations=(mine.categories||[]).filter(c=>/^[\da-f]{8}-[\da-f-]{27,}$/i.test(String(c.id)));
    const selected=new Set();
    let filter='all',query='',saving=false,finished=false;
    clear(body);
    if(!destinations.length){body.append(el('p','rs-fimport-notice','Crie uma categoria na sua biblioteca antes de importar jogos.'));return;}
    const summary=el('div','rs-fimport-summary');body.append(summary);
    const toolbar=el('div','rs-fimport-toolbar');
    const sourceCat=el('select','rs-fimport-select');sourceCat.setAttribute('aria-label','Categoria do outro perfil');
    const all=el('option','','Todas as categorias públicas');all.value='all';sourceCat.append(all);
    for(const c of publicCategories){const opt=el('option','',c.name);opt.value=String(c.id);sourceCat.append(opt)}
    const search=el('input','rs-fimport-search');search.type='search';search.placeholder='Pesquisar jogos públicos...';search.maxLength=120;search.setAttribute('aria-label','Pesquisar jogos para importar');
    toolbar.append(sourceCat,search);body.append(toolbar);
    const choose=el('div','rs-fimport-choose');
    const selectAll=btn('Selecionar novos desta seleção',()=>{for(const g of filtered())if(!owned.has(g.id)&&selected.size<100)selected.add(g.id);status.textContent=selected.size===100?'Máximo de 100 jogos por importação. Você pode importar o restante depois.':'';draw();},'rs-fimport-small');
    const deselect=btn('Limpar seleção',()=>{selected.clear();draw()},'rs-fimport-small');
    const count=el('span','rs-fimport-count');choose.append(selectAll,deselect,count);body.append(choose);
    const list=el('div','rs-fimport-list');body.append(list);
    const destRow=el('div','rs-fimport-destination');
    const destLabel=el('label','','Salvar jogos novos em');destLabel.htmlFor='rblxs-import-destination';
    const dest=el('select','rs-fimport-select');dest.id='rblxs-import-destination';
    for(const c of destinations){const opt=el('option','',`${c.name}${c.is_private?' 🔒':''}`);opt.value=String(c.id);dest.append(opt)}
    destRow.append(destLabel,dest);body.append(destRow);
    const status=el('p','rs-fimport-status');status.setAttribute('aria-live','polite');body.append(status);
    const footer=el('div','rs-fimport-actions');
    const cancel=btn('Cancelar',closeProfileImport,'rs-fimport-close');
    const commit=btn('Importar 0 jogos',()=>void confirmImport(),'rs-fimport-confirm');
    footer.append(cancel,commit);body.append(footer);
    const note=el('p','rs-fimport-note','Jogos que você já possui são ignorados. As categorias e a ordem dos seus jogos atuais não serão modificadas. Só são importados jogos que ainda são públicos no momento do salvamento.');body.append(note);
    function filtered(){
      const term=rsSearchText(query.trim());
      return sourceRows.filter(g=>(filter==='all'||g.categoryId===filter)&&(!term||rsSearchText(g.name).includes(term)));
    }
    function draw(){
      const available=sourceRows.filter(g=>!owned.has(g.id));
      summary.textContent=`${sourceRows.length} públicos · ${available.length} novos · ${sourceRows.length-available.length} já na sua biblioteca`;
      count.textContent=`${selected.size} selecionados`;
      commit.textContent=finished?'Importação concluída':`Importar ${selected.size} ${selected.size===1?'jogo':'jogos'}`;
      commit.disabled=saving||finished||!selected.size||selected.size>100;
      selectAll.disabled=saving||finished;deselect.disabled=saving||finished;
      sourceCat.disabled=saving||finished;search.disabled=saving||finished;dest.disabled=saving||finished;
      cancel.disabled=saving;close.disabled=saving;
      clear(list);
      const shown=filtered();
      if(!shown.length){list.append(el('p','rs-fimport-notice',query?'Nenhum jogo corresponde à pesquisa.':'Nenhum jogo público nesta categoria.'));return;}
      const fragment=document.createDocumentFragment();
      for(const g of shown.slice(0,250)){
        const existing=owned.has(g.id);
        const label=el('label','rs-fimport-game'+(existing?' rs-fimport-existing':''));
        const checkbox=el('input');checkbox.type='checkbox';checkbox.checked=selected.has(g.id);checkbox.disabled=existing||saving||finished;
        checkbox.addEventListener('change',()=>{if(checkbox.checked){if(selected.size>=100){checkbox.checked=false;status.textContent='Limite de 100 jogos por importação.';return}selected.add(g.id)}else selected.delete(g.id);draw()});
        const img=el('img');img.src=imageUrl(g)||'';img.alt='';img.loading='lazy';
        const info=el('div','rs-fimport-game-info');info.append(el('strong','',g.name),el('small','',g.categoryName));
        label.append(checkbox,img,info,el('span','rs-fimport-game-state',existing?'Já possui':'Novo'));fragment.append(label);
      }
      list.append(fragment);
      if(shown.length>250)list.append(el('p','rs-fimport-notice','Exibindo 250 resultados. Use a pesquisa para encontrar outros jogos.'));
    }
    sourceCat.addEventListener('change',()=>{filter=sourceCat.value;draw()});
    search.addEventListener('input',()=>{query=search.value;draw()});
    async function confirmImport(){
      if(saving||finished||!selected.size)return;
      if(selected.size>100){status.textContent='Importe no máximo 100 jogos de cada vez.';return}
      const ids=[...selected];const categoryId=dest.value;
      // Explicit confirmation screen before any persistent write.
      if(!window.confirm(`Importar ${ids.length} jogo(s) público(s) para "${dest.selectedOptions[0]?.textContent||'categoria'}"?\nOs jogos já existentes serão preservados.`))return;
      saving=true;importInFlight=true;status.textContent='Importando e conferindo permissões no servidor...';draw();
      try{
        // Persist pending edits first, to avoid modifying or replacing staged changes.
        await msg('ROSHELF_COMMIT_GAMES',{ownerId});
        const result=await msg('ROSHELF_IMPORT_FRIEND',{sourceUserId,categoryId,gameIds:ids});
        finished=true;const countAdded=Number(result.added)||0;
        const skipped=ids.length-countAdded;
        status.textContent=`Pronto! ${countAdded} ${countAdded===1?'jogo importado':'jogos importados'}${skipped?` · ${skipped} já existente(s) ignorado(s)`:''}.`;
        selected.clear();await fetchOwn();
      }catch(e){status.textContent='Não foi possível concluir: '+String(e?.message||e)+'. Você pode tentar novamente.';}
      finally{saving=false;importInFlight=false;draw()}
    }
    draw();
  }catch(e){if(epoch===importEpoch&&overlay.isConnected){clear(body);body.append(el('p','rs-fimport-error','Não foi possível preparar a importação: '+String(e.message||e)));}}
}
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&document.getElementById('rblxs-import-overlay')){e.preventDefault();closeProfileImport()}});

function buildProfile(){
  const p=el('section');p.id='rblxs-profile';
  const owner=isOwn();
  const header=el('div','rs-profile-header');header.append(el('h3','','RoShelf'));
  const actions=el('div','rs-profile-header-actions');
  const searchToggle=btn(profileSearchOpen?'✕ Fechar busca':'⌕ Buscar jogos',()=>{profileSearchOpen=!profileSearchOpen;refreshProfile();if(profileSearchOpen)document.getElementById('rblxs-profile-search-input')?.focus()},'rs-profile-search-toggle');
  searchToggle.setAttribute('aria-expanded',String(profileSearchOpen));searchToggle.setAttribute('aria-controls','rblxs-profile-search-panel');
  actions.append(searchToggle);
  const statsButton=btn('▥ Estatísticas',()=>openProfileStats(statsButton),'rs-profile-stats-toggle');
  statsButton.setAttribute('aria-haspopup','dialog');
  statsButton.title='Ver gráficos e números da biblioteca';
  statsButton.disabled=viewLoading||!viewData;
  actions.append(statsButton);
  if(oauthProfile && !owner){
    const compareBtn=btn('⇄ Comparar comigo',()=>void openProfileCompare(compareBtn),'rs-profile-compare-toggle');
    compareBtn.setAttribute('aria-haspopup','dialog');compareBtn.title='Comparar apenas jogos públicos pela preferência de 1 a 5';
    compareBtn.disabled=viewLoading||!viewData?.exists;actions.append(compareBtn);
    const importBtn=btn('⇩ Importar jogos',()=>void openProfileImport(importBtn),'rs-profile-import-toggle');
    importBtn.setAttribute('aria-haspopup','dialog');importBtn.title='Copiar somente jogos públicos que ainda não estão na sua biblioteca';
    importBtn.disabled=viewLoading||!viewData?.exists;actions.append(importBtn);
  }
  if(owner){
    const editHighlights=btn(featuredEditing?'★ Editando destaques':'☆ Editar destaques',()=>{if(!featuredEditing)beginFeaturedEdit();else void finishFeaturedEdit()},'rs-edit-featured');
    editHighlights.disabled=featuredSaving;
    actions.append(editHighlights,btn('Editar minha lista',openEditor,'rs-edit-profile'));
  }
  header.append(actions);p.append(header);
  const shell=el('div','rs-profile-shell');p.append(shell);
  const layout=el('div','rs-profile-layout');shell.append(layout);
  const side=el('div','rs-side');layout.append(side);
  const profileCats=(viewData?.categories||[]).slice().sort((a,b)=>Number(a.sort_order)-Number(b.sort_order));
  const categories=profileCats.length?profileCats.map(c=>(viewData?.games||[]).filter(g=>g.category_id===c.id||(!g.category_id&&c.legacy_key===g.category)).map(g=>({id:String(g.universe_id),placeId:g.place_id?String(g.place_id):'',name:g.game_name||'Jogo',image:g.image_url||''}))):viewData?.exists?toLists(viewData):empty();
  const catNames=profileCats.length?profileCats.map(c=>c.name):CATS;
  // Server filters all private categories from the public GET response.
  // Owner-only edit mode uses their authenticated library.
  const visibleGames=viewData?.games||[];
  const catalog=owner&&featuredEditing?featureLibrary():null;
  const ranked=owner&&featuredEditing?
    featuredDraft.map(id=>catalog.get(id)).filter(Boolean):
    visibleGames.filter(g=>Number.isInteger(Number(g.featured_position))&&Number(g.featured_position)>=1&&Number(g.featured_position)<=3)
      .sort((a,b)=>Number(a.featured_position)-Number(b.featured_position)).slice(0,3)
      .map(g=>({id:String(g.universe_id),placeId:g.place_id?String(g.place_id):'',name:g.game_name||'Jogo',image:g.image_url||''}));
  const featured=buildFeaturedSection(ranked,owner);
  if(featured)p.insertBefore(featured,shell);
  if(profileSearchOpen){
    const panel=buildProfileSearchPanel(viewData);panel.id='rblxs-profile-search-panel';
    p.append(panel);shell.hidden=true;return p;
  }
  if(profileTab>=catNames.length)profileTab=0;
  catNames.forEach((name,i)=>{const b=btn(name,()=>{profileTab=i;refreshProfile()},'rs-tab');b.dataset.active=String(profileTab===i);b.append(el('span','rs-count',String(categories[i].length)));side.append(b)});
  const view=el('div','rs-view');layout.append(view);const rail=el('div','rs-rail');view.append(rail);const games=categories[profileTab]||[];
  if(viewLoading)rail.append(el('div','rs-empty','Carregando lista...'));
  else if(viewError)rail.append(el('div','rs-empty','Erro ao carregar: '+viewError));
  else if(!viewData?.exists)rail.append(el('div','rs-empty','Este perfil ainda não tem uma lista RoShelf.'));
  else if(!games.length)rail.append(el('div','rs-empty','Nenhum jogo nesta categoria.'));
  else {const track=el('div','rs-track');rail.append(track);games.forEach(g=>{const c=el('div','rs-card');const a=el('a','rs-card-link');const url=gameUrl(g);if(url){a.href=url;a.target='_blank';a.rel='noopener noreferrer'}else a.removeAttribute('href');const img=el('img');img.src=imageUrl(g)||'';img.alt='';img.loading='lazy';a.append(img,el('span','rs-card-name',g.name));c.append(a);track.append(c)});const arrows=el('div','rs-arrows');arrows.append(btn('‹',()=>track.scrollBy({left:-340,behavior:'smooth'}),'rs-arrow'),btn('›',()=>track.scrollBy({left:340,behavior:'smooth'}),'rs-arrow'));rail.append(arrows)}
  return p;
}
function refreshProfile(){if(!viewedProfileId())return;const old=document.getElementById('rblxs-profile');if(old)old.replaceWith(buildProfile());else mountProfile()}
// Sections on Roblox profiles can use h2/h3 or plain spans/divs, and
// Portuguese profiles use 'Amizades' instead of 'Amigos'. Avoid relying on
// a single heading tag or language when inserting the public shelf.
function profileHeading(pattern){
  const root=document.querySelector('#container-main, main, [role="main"]')||document.body;
  const primary=root.querySelectorAll('h2,h3,h4,h5,[role="heading"],.container-header,.section-header');
  const good=e=>{
    if(!e||e.closest('#rblxs-app,#rblxs-profile,#rblxs-nav,#rblxs-float'))return false;
    const t=(e.textContent||'').replace(/\s+/g,' ').trim();
    return t.length<=65&&pattern.test(t);
  };
  for(const e of primary)if(good(e))return e;
  // Newer Roblox layouts use generic text elements as section headers.
  for(const e of root.querySelectorAll('span,div,a')){
    if(e.childElementCount>3||!good(e))continue;
    if([...e.children].some(child=>good(child)))continue;
    return e;
  }
  return null;
}
function betweenProfileSections(fav,friends){
  if(!fav||!friends)return false;
  const ancestors=new Set();
  for(let n=fav;n;n=n.parentElement)ancestors.add(n);
  let root=friends;
  while(root&&!ancestors.has(root))root=root.parentElement;
  if(!root||root===fav||root===friends)return false;
  let f=fav,n=friends;
  while(f.parentElement&&f.parentElement!==root)f=f.parentElement;
  while(n.parentElement&&n.parentElement!==root)n=n.parentElement;
  if(f===n||!n.parentElement||f.compareDocumentPosition(n)&Node.DOCUMENT_POSITION_PRECEDING)return false;
  // Insert at the shared section boundary: directly before Friends/Amizades.
  n.insertAdjacentElement('beforebegin',buildProfile());
  return true;
}
function mountProfile(){
  if(!viewedProfileId()||document.getElementById('rblxs-profile'))return;
  const fav=profileHeading(/^(?:favorites|favoritos)(?:\s*[>›→])?$/i);
  const friends=profileHeading(/^(?:friends|amigos|amizades)(?:\s*\(\s*\d+\s*\))?(?:\s*[>›→])?$/i);
  if(betweenProfileSections(fav,friends))return;
  if(fav){
    let a=fav;
    for(let i=0;i<5&&a.parentElement;i++){
      if(a.querySelectorAll('img').length>=3)break;
      if(friends&&a.contains(friends))break;
      a=a.parentElement;
    }
    if(a.parentElement&&a!==document.body&&a!==document.documentElement){
      a.insertAdjacentElement('afterend',buildProfile());return;
    }
  }
  if(friends){
    const section=friends.closest('section,.profile-section,.rbx-section,.profile-container-section');
    if(section&&section!==document.body){section.insertAdjacentElement('beforebegin',buildProfile());return}
    let a=friends;
    // Find the top of the Friends block (heading + avatar thumbnails).
    for(let i=0;i<5&&a.parentElement;i++){
      if(a.querySelectorAll('img').length>=3)break;
      a=a.parentElement;
    }
    if(a.parentElement&&a!==document.body&&a!==document.documentElement){
      a.insertAdjacentElement('beforebegin',buildProfile());return;
    }
  }
  // Wait for the Roblox profile to finish rendering instead of placing
  // a panel somewhere unrelated. MutationObserver retries automatically.
}

function mountNav(){if(document.getElementById('rblxs-nav'))return;const candidates=['#navigation','#navigation-container','#left-navigation','nav[aria-label="Navigation"]','.left-col-list','.nav-container'];let nav=candidates.map(q=>document.querySelector(q)).find(n=>n&&n.getBoundingClientRect().height>80);if(!nav){const e=[...document.querySelectorAll('a')].find(a=>/\/users\/profile|\/my\/avatar/.test(a.getAttribute('href')||''));nav=e?.closest('ul')||e?.parentElement?.parentElement}if(nav){document.getElementById('rblxs-float')?.remove();const b=btn('▣   RoShelf',openEditor);b.id='rblxs-nav';nav.append(b)}else if(!document.getElementById('rblxs-float')){const b=btn('▣ RoShelf',openEditor);b.id='rblxs-float';document.body.append(b)}}
function routeTick(){if(!document.body)return;const id=viewedProfileId();if(id!==profileSearchUserId){closeProfileCompare();closeProfileStats();profileSearchUserId=id;profileSearchOpen=false;profileSearchQuery='';profileSearchCategory='all';profileSearchSort='custom';}if(location.pathname!==lastRoute){lastRoute=location.pathname;document.getElementById('rblxs-profile')?.remove();if(id)fetchViewed(id);else{viewingId='';requestSerial++;viewData=null}}mountNav();mountProfile()}
// Chrome toolbar popup: only explicit, allowlisted actions open our existing UI.
chrome.runtime.onMessage.addListener((request, sender, respond) => {
  if (request?.kind !== 'ROSHELF_POPUP_OPEN') return;
  if (request.panel !== 'editor' && request.panel !== 'categories') {
    respond({ok:false,error:'Painel inválido.'});return;
  }
  if (request.panel === 'categories') categoriesOpen=true;
  openEditor();
  respond({ok:true});
});
// New Roblox tab fallback: open the requested panel after content script initializes.
function consumePopupOpenRequest(){
  const u=new URL(location.href);
  const panel=u.searchParams.get('roshelfPanel');
  if (panel !== 'editor' && panel !== 'categories') return;
  u.searchParams.delete('roshelfPanel');
  history.replaceState(history.state,'',u.pathname+u.search+u.hash);
  if (panel === 'categories') categoriesOpen=true;
  openEditor();
}
refreshLocalCount();
msg('ROSHELF_SESSION').then(async r=>{oauthProfile=r.profile||null;if(oauthProfile)await fetchOwn();refreshProfile();drawEditor()}).catch(()=>{});
window.addEventListener('pagehide',()=>{if(categoriesOpen||categoryRevision>0){void flushCategoryJobs()}void commitGameEdits()});
routeTick();consumePopupOpenRequest();let scheduled=false;new MutationObserver(()=>{if(scheduled)return;scheduled=true;setTimeout(()=>{scheduled=false;routeTick()},650)}).observe(document.documentElement,{subtree:true,childList:true});setInterval(routeTick,3500);
})();
