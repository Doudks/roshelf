/* RoShelf toolbar popup — no tokens are read or stored here. */
'use strict';
const $=id=>document.getElementById(id);
const api=(kind)=>new Promise((resolve,reject)=>chrome.runtime.sendMessage({kind},response=>{
  const error=chrome.runtime.lastError;
  if(error)return reject(new Error(error.message));
  if(!response?.ok)return reject(new Error(response?.error||'Erro ao consultar a extensão.'));
  resolve(response);
}));
let profile=null;
$('version').textContent='v'+chrome.runtime.getManifest().version;
function status(message){$('message').textContent=message||'';}
async function updateSession(){
  try{
    const data=await api('ROSHELF_SESSION');
    profile=data.profile||null;
    const dot=$('status-dot');
    dot.className='status-dot '+(profile?'online':'offline');
    dot.title=profile?'Conectada':'Desconectada';
    if(profile){
      $('account-name').textContent=profile.displayName||profile.username||'Conta conectada';
      $('account-desc').textContent='@'+(profile.username||'Roblox')+' · Conectada';
      const imgUrl=String(profile.picture||'');
      if(/^https:\/\/tr\.rbxcdn\.com\//.test(imgUrl)){
        const img=document.createElement('img');img.src=imgUrl;img.alt='';
        $('avatar').replaceChildren(img);
      }else{$('avatar').textContent='R';}
    }else{
      $('account-name').textContent='Roblox não conectado';
      $('account-desc').textContent='Abra o editor para conectar';
      $('avatar').textContent='R';
    }
  }catch(e){
    $('status-dot').className='status-dot offline';
    $('account-name').textContent='Não foi possível verificar a sessão';
    $('account-desc').textContent='Você ainda pode abrir o Roblox';
  }
}
const ROBLOX='https://www.roblox.com';
async function openPanel(panel){
  status('');
  const btn=document.querySelector(`[data-panel="${panel}"]`);
  if(btn)btn.disabled=true;
  try{
    // When the active tab is Roblox, use the already running content script.
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    if(tab?.id && typeof tab.url==='string' && new URL(tab.url).origin===ROBLOX){
      try{
        const answer=await chrome.tabs.sendMessage(tab.id,{kind:'ROSHELF_POPUP_OPEN',panel});
        if(answer?.ok){window.close();return;}
      }catch(_){/* Content script not loaded yet; open a fresh Roblox tab. */}
    }
    const path=(profile?.id && /^\d+$/.test(String(profile.id)))
      ? `/users/${profile.id}/profile` : '/home';
    const target=new URL(path,ROBLOX);
    target.searchParams.set('roshelfPanel',panel);
    await chrome.tabs.create({url:target.href,active:true});
    window.close();
  }catch(e){status('Não consegui abrir o Roblox. Tente novamente.');}
  finally{if(btn)btn.disabled=false;}
}
for(const btn of document.querySelectorAll('[data-panel]'))btn.addEventListener('click',()=>openPanel(btn.dataset.panel));
$('my-profile').addEventListener('click',async()=>{
  const id=profile?.id;
  const path=id && /^\d+$/.test(String(id)) ? `/users/${id}/profile` : '/home';
  try{await chrome.tabs.create({url:ROBLOX+path});window.close()}
  catch(e){status('Não consegui abrir seu perfil.');}
});
$('official-site').addEventListener('click',async()=>{
  try{await chrome.tabs.create({url:'https://doudks.github.io/roshelf/'});window.close()}
  catch(e){status('Não consegui abrir o site.');}
});
void updateSession();
