// Only public game metadata is fetched. No Roblox cookies or credentials are read.
chrome.runtime.onMessage.addListener((msg,sender,respond)=>{
  if(msg?.kind!=='RS_FIND_GAME')return;
  (async()=>{
    const q=String(msg.query||'').trim();
    if(!q)throw Error('Digite um nome ou link de jogo.');
    const uri=q.match(/roblox\.com\/(?:[a-z]{2}\/)?games\/(\d+)/i);
    if(uri){
      const placeId=uri[1];
      const universeReq=await fetch(`https://apis.roblox.com/universes/v1/places/${placeId}/universe`);
      if(!universeReq.ok)throw Error('Não consegui identificar o universo deste link.');
      const uni=await universeReq.json();
      if(!uni.universeId)throw Error('Jogo não encontrado.');
      const detail=await fetch(`https://games.roblox.com/v1/games?universeIds=${uni.universeId}`);
      if(!detail.ok)throw Error('Não consegui consultar o jogo.');
      const info=(await detail.json()).data?.[0];
      if(!info)throw Error('Jogo não encontrado.');
      respond({ok:true,games:await addThumbs([{id:String(info.id),placeId:String(info.rootPlaceId),name:info.name}])});return;
    }
    // Roblox search endpoints change periodically; try multiple documented/observed forms.
    const endpoints=[
      `https://apis.roblox.com/search-api/omni-search?SearchQuery=${encodeURIComponent(q)}&SessionId=${crypto.randomUUID()}`,
      `https://www.roblox.com/discover-api/v1/search?keyword=${encodeURIComponent(q)}`
    ];
    let found=[];
    for(const url of endpoints){
      try{
        const r=await fetch(url,{headers:{Accept:'application/json'}});
        if(!r.ok)continue;
        const data=await r.json();
        const candidates=[];
        function dig(value,depth){
          if(depth>7||!value||typeof value!=='object')return;
          if(Array.isArray(value)){for(const item of value.slice(0,100))dig(item,depth+1);return}
          const id=value.universeId??(value.universe?.id)??(value.rootPlaceId?value.id:undefined);
          const place=value.rootPlaceId??value.placeId??value.place?.id;
          const name=value.name??value.title??value.gameName;
          if(id&&name&&typeof name==='string')candidates.push({id:String(id),placeId:place?String(place):'',name});
          for(const [key,child] of Object.entries(value))if(typeof child==='object')dig(child,depth+1);
        }
        dig(data,0);
        found=[...new Map(candidates.map(x=>[x.id,x])).values()].slice(0,18);
        if(found.length)break;
      }catch(_){}
    }
    if(!found.length)throw Error('A busca por nome não retornou resultados. Cole o link de um jogo do Roblox para adicioná-lo.');
    respond({ok:true,games:await addThumbs(found)});
  })().catch(e=>respond({ok:false,error:e.message}));
  return true;
});
async function addThumbs(games){
  try{
    const r=await fetch(`https://thumbnails.roblox.com/v1/games/icons?universeIds=${games.map(g=>g.id).join(',')}&returnPolicy=PlaceHolder&size=150x150&format=Png&isCircular=false`);
    if(r.ok){const data=(await r.json()).data||[];const m=new Map(data.map(t=>[String(t.targetId),t.imageUrl]));return games.map(g=>({...g,image:m.get(g.id)||''}));}
  }catch(_){}
  return games;
}


// RoShelf OAuth 2.0 — Authorization Code + PKCE; NEVER embed a client secret.
// Persist rotating refresh tokens in extension-only storage to restore logins.
const ROSHELF_OAUTH_CLIENT_ID = '8489982182379473837';
const ROSHELF_AUTH_KEY = 'roshelf_oauth_session_08';
const ROSHELF_OAUTH_ROOT = 'https://apis.roblox.com/oauth/v1';
let roshelfLoginPending = false;

function roshelfBase64Url(bytes) {
  let binary='';
  for (const b of bytes) binary += String.fromCharCode(b);
  return btoa(binary).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
function roshelfNonce() { return roshelfBase64Url(crypto.getRandomValues(new Uint8Array(32))); }
// chrome.storage.local survives browser restarts, unlike chrome.storage.session.
// Restrict stored secrets from content scripts; only this service worker uses them.
const ROSHELF_REFRESH_KEY = 'roshelf_oauth_refresh_011';
// storage.local contains a sensitive credential; deny content script access.
const roshelfRestrictedStorage = chrome.storage.local.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'});
const ROSHELF_OLD_REFRESH_KEY = 'roshelf_oauth_refresh_010';
let roshelfRefreshPending = null;
async function roshelfRefreshStore() {
  await roshelfRestrictedStorage;
  // Extension storage is not encrypted: do not install untrusted extensions or share your browser profile.
  const items = await chrome.storage.local.get([ROSHELF_REFRESH_KEY, ROSHELF_OLD_REFRESH_KEY]);
  return items[ROSHELF_REFRESH_KEY] || items[ROSHELF_OLD_REFRESH_KEY] || null;
}
async function roshelfForgetSession() {
  await roshelfRestrictedStorage;
  await chrome.storage.session.remove(ROSHELF_AUTH_KEY);
  await chrome.storage.local.remove([ROSHELF_REFRESH_KEY, ROSHELF_OLD_REFRESH_KEY]);
}
async function roshelfRefreshSession() {
  if (roshelfRefreshPending) return roshelfRefreshPending;
  roshelfRefreshPending = (async () => {
    const cache = (await chrome.storage.session.get(ROSHELF_AUTH_KEY))[ROSHELF_AUTH_KEY];
    if (cache?.accessToken && cache?.profile && Date.now() < cache.expiresAt) return cache;
    const stored = await roshelfRefreshStore();
    if (!stored?.refreshToken || !stored?.profile) return null;
    let response;
    try {
      response = await fetch(`${ROSHELF_OAUTH_ROOT}/token`, {
        method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:new URLSearchParams({grant_type:'refresh_token',refresh_token:stored.refreshToken,client_id:ROSHELF_OAUTH_CLIENT_ID}).toString(),
        signal:AbortSignal.timeout(15000)
      });
    } catch (_) {
      // Temporary network failure: preserve refresh token for a later retry.
      throw Error('Não foi possível renovar a sessão. Verifique a internet e tente novamente.');
    }
    if (!response.ok) {
      // 400/401 indicates invalid/revoked/expired token. Do not retry a consumed token.
      if (response.status === 400 || response.status === 401) {
        await roshelfForgetSession();
        return null;
      }
      throw Error(`Roblox não conseguiu renovar a sessão (HTTP ${response.status}). Tente novamente.`);
    }
    const tokens = await response.json();
    if (!tokens.access_token || !tokens.refresh_token) {
      throw Error('A renovação não retornou os tokens necessários.');
    }
    // Rotate refresh tokens. Refresh tokens are single-use at Roblox.
    await roshelfRestrictedStorage;
    await chrome.storage.local.set({[ROSHELF_REFRESH_KEY]:{profile:stored.profile,refreshToken:tokens.refresh_token}});
    await chrome.storage.local.remove(ROSHELF_OLD_REFRESH_KEY);
    const updated = {profile:stored.profile, accessToken:tokens.access_token,
      expiresAt:Date.now()+Math.max(30,Math.min(900,Number(tokens.expires_in)||899)-20)*1000};
    await chrome.storage.session.set({[ROSHELF_AUTH_KEY]:updated});
    return updated;
  })();
  try { return await roshelfRefreshPending; }
  finally { roshelfRefreshPending=null; }
}
async function roshelfEnsureSession() {
  const cached=(await chrome.storage.session.get(ROSHELF_AUTH_KEY))[ROSHELF_AUTH_KEY];
  if (cached?.accessToken && cached?.profile && Date.now()<cached.expiresAt) return cached;
  return roshelfRefreshSession();
}
async function roshelfSession() {
  const data=await roshelfEnsureSession();
  if (!data?.profile) return null;
  // Never return tokens to content scripts or Roblox pages.
  return {id:String(data.profile.sub), username:String(data.profile.preferred_username||''),
    displayName:String(data.profile.name||''), picture:String(data.profile.picture||''),expiresAt:data.expiresAt};
}
async function roshelfLogin() {
  if (roshelfLoginPending) throw Error('Uma janela de conexão já está aberta.');
  roshelfLoginPending = true;
  try {
    const redirect = chrome.identity.getRedirectURL();
    const verifier=roshelfNonce();
    const digest = new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(verifier)));
    const challenge = roshelfBase64Url(digest);
    const state = roshelfNonce();
    const url = new URL(`${ROSHELF_OAUTH_ROOT}/authorize`);
    url.search = new URLSearchParams({client_id:ROSHELF_OAUTH_CLIENT_ID,
      redirect_uri:redirect,response_type:'code',scope:'openid profile',
      code_challenge:challenge,code_challenge_method:'S256',state}).toString();
    const redirected = await chrome.identity.launchWebAuthFlow({url:url.href,interactive:true});
    if (!redirected) throw Error('O Roblox não retornou o código de autorização.');
    const result = new URL(redirected);
    const expected = new URL(redirect);
    if (result.origin !== expected.origin || result.pathname !== expected.pathname) throw Error('Redirect URL inesperada.');
    if (result.searchParams.get('state') !== state) throw Error('Verificação de segurança (state) falhou.');
    if (result.searchParams.has('error')) throw Error('Roblox recusou a autorização: ' + result.searchParams.get('error'));
    const code = result.searchParams.get('code');
    if (!code) throw Error('O Roblox não retornou o código de login.');
    const body = new URLSearchParams({client_id: ROSHELF_OAUTH_CLIENT_ID,grant_type:'authorization_code',code,code_verifier:verifier});
    const tokenResponse = await fetch(`${ROSHELF_OAUTH_ROOT}/token`, {
      method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:body.toString()});
    if (!tokenResponse.ok) throw Error('Falha na troca do código OAuth (HTTP '+tokenResponse.status+'). Verifique a Redirect URL e o tipo público/PKCE.');
    const tokens = await tokenResponse.json();
    if (!tokens.access_token || !tokens.refresh_token) throw Error('A resposta OAuth não contém os tokens necessários.');
    const userResponse = await fetch(`${ROSHELF_OAUTH_ROOT}/userinfo`, {
      headers:{Authorization:'Bearer '+tokens.access_token}});
    if (!userResponse.ok) throw Error('Não consegui identificar a conta (userinfo HTTP '+userResponse.status+').');
    const profile=await userResponse.json();
    if (!/^\d+$/.test(String(profile.sub || ''))) throw Error('A resposta não possui um Roblox User ID válido.');
    const expiresAt=Date.now()+Math.min(900,Number(tokens.expires_in)||899)*1000-20000;
    const safeProfile={sub:String(profile.sub),name:profile.name||'',preferred_username:profile.preferred_username||'',picture:profile.picture||''};
    // Save rotating refresh token in persistent extension-only storage.
    await roshelfRestrictedStorage;
    await chrome.storage.local.set({[ROSHELF_REFRESH_KEY]:{profile:safeProfile,refreshToken:tokens.refresh_token}});
    await chrome.storage.local.remove(ROSHELF_OLD_REFRESH_KEY);
    await chrome.storage.session.set({[ROSHELF_AUTH_KEY]:{profile:safeProfile,accessToken:tokens.access_token,expiresAt}});
    return await roshelfSession();
  } finally {roshelfLoginPending = false;}
}
chrome.runtime.onMessage.addListener((msg,sender,respond)=>{
  if (!msg || !['ROSHELF_LOGIN','ROSHELF_SESSION','ROSHELF_LOGOUT','ROSHELF_REDIRECT'].includes(msg.kind)) return;
  (async()=>{
    if (msg.kind==='ROSHELF_LOGIN') return {ok:true,profile:await roshelfLogin()};
    if (msg.kind==='ROSHELF_SESSION') return {ok:true,profile:await roshelfSession()};
    if (msg.kind==='ROSHELF_LOGOUT') {await roshelfForgetSession();return {ok:true};}
    if (msg.kind==='ROSHELF_REDIRECT') return {ok:true,url:chrome.identity.getRedirectURL()};
  })().then(respond).catch(e=>respond({ok:false,error:String(e.message||e)}));
  return true;
});


// RoShelf 0.9: remote storage. Every write is bound to a verified Roblox OAuth
// bearer in the Edge Function. Tokens never cross into content scripts.
const ROSHELF_API = 'https://firicnomahngsqnqplsa.supabase.co/functions/v1/roshelf-api';
async function roshelfRawSession() {
  const data=await roshelfEnsureSession();
  if (!data?.accessToken) throw Error('Sua sessão Roblox terminou. Clique em Conectar com Roblox.');
  return data;
}
async function roshelfRequest(method, userId, action, payload) {
  const options = {method, cache:'no-store', credentials:'omit', headers:{Accept:'application/json'},signal:AbortSignal.timeout(45000)};
  const url = new URL(ROSHELF_API);
  if (method === 'GET') {
    if (!/^[1-9]\d{0,18}$/.test(String(userId||''))) throw Error('ID Roblox inválido.');
    url.searchParams.set('userId',String(userId));
  } else {
    const s = await roshelfRawSession();
    options.headers.Authorization = 'Bearer ' + s.accessToken;
    options.headers['Content-Type'] = 'application/json';
    options.body = JSON.stringify({action,...payload});
  }
  const startedAt = Date.now();
  let response;
  try {
    response = await fetch(url.href, options);
  } catch (e) {
    const elapsed = ((Date.now() - startedAt) / 1000).toFixed(1);
    console.warn('[RoShelf API]', action || method, 'falhou após', elapsed, 's', e);
    if (e?.name === 'TimeoutError' || e?.name === 'AbortError') {
      throw Error(`Servidor não respondeu em ${elapsed}s. Verifique os Logs da Edge Function; o salvamento pode ter sido concluído.`);
    }
    throw e;
  }
  console.info('[RoShelf API]', action || method, 'HTTP', response.status, 'em', ((Date.now()-startedAt)/1000).toFixed(1), 's');
  let data;
  try {data=await response.json();}catch {throw Error(`A API respondeu HTTP ${response.status} sem JSON válido.`)}
  if(!response.ok || !data?.ok)throw Error(data?.error||`Erro HTTP ${response.status}`);
  return data;
}
chrome.runtime.onMessage.addListener((msg,sender,reply)=>{
  if(!msg || !['ROSHELF_GET_LIST','ROSHELF_OWNER_LIST','ROSHELF_CATEGORY_CREATE','ROSHELF_CATEGORY_UPDATE','ROSHELF_CATEGORY_DELETE','ROSHELF_ADD_GAME','ROSHELF_REMOVE_GAME','ROSHELF_IMPORT_LOCAL','ROSHELF_STAGE_GAME','ROSHELF_COMMIT_GAMES','ROSHELF_STAGE_LAYOUT','ROSHELF_FEATURED_SET','ROSHELF_IMPORT_FRIEND'].includes(msg.kind))return;
  (async()=>{
    switch(msg.kind){
      case 'ROSHELF_STAGE_GAME': return await roshelfStageGame(msg.ownerId,msg.change,sender.tab?.id);
      case 'ROSHELF_STAGE_LAYOUT': return await roshelfStageLayout(msg.ownerId,msg.lists,sender.tab?.id);
      case 'ROSHELF_COMMIT_GAMES': return await roshelfCommitGames(msg.ownerId);
      case 'ROSHELF_LOCAL_COUNT': {
        const saved=(await chrome.storage.local.get('rblxs_local_games_v01')).rblxs_local_games_v01;
        return {ok:true,count:Array.isArray(saved)?saved.reduce((n,a)=>n+(Array.isArray(a)?a.length:0),0):0};
      }
      case 'ROSHELF_GET_LIST': return await roshelfRequest('GET',msg.userId);
      case 'ROSHELF_FEATURED_SET': return await roshelfRequest('POST',null,'featured_set',{games:msg.games});
      case 'ROSHELF_IMPORT_FRIEND': return await roshelfRequest('POST',null,'import_games',{source_user_id:msg.sourceUserId,destination_category_id:msg.categoryId,universe_ids:msg.gameIds});
      case 'ROSHELF_OWNER_LIST': return await roshelfRequest('POST',null,'owner_list',{});
      case 'ROSHELF_CATEGORY_CREATE': return await roshelfRequest('POST',null,'category_create',{name:msg.name,preference:msg.preference,is_private:msg.isPrivate});
      case 'ROSHELF_CATEGORY_UPDATE': return await roshelfRequest('POST',null,'category_update',{category_id:msg.categoryId,...msg.patch});
      case 'ROSHELF_CATEGORY_DELETE': return await roshelfRequest('POST',null,'category_delete',{category_id:msg.categoryId});
      case 'ROSHELF_ADD_GAME': return await roshelfRequest('POST',null,'add',{game:msg.game,category:msg.category});
      case 'ROSHELF_REMOVE_GAME': return await roshelfRequest('POST',null,'remove',{universe_id:msg.universeId});
      case 'ROSHELF_IMPORT_LOCAL': {
        const saved = (await chrome.storage.local.get('rblxs_local_games_v01')).rblxs_local_games_v01;
        if(!Array.isArray(saved)||saved.length!==6) return {ok:true,added:0,failed:0};
        const categories = ['quero_muito_jogar','jogaria_um_pouco','jogaria_no_odio','posso_testar','lua_azul','nem_me_chama'];
        let added=0,failed=0;
        for (let i=0;i<6;i++)for (const g of Array.isArray(saved[i])?saved[i].slice(0,500):[]) {
          if(!/^[1-9]\d{0,18}$/.test(String(g.id||''))) {failed++;continue}
          try {
            await roshelfRequest('POST',null,'add',{category:categories[i],game:{universe_id:String(g.id),place_id:g.placeId||null,game_name:String(g.name||'Jogo'),image_url:g.image||null}});
            added++;
          }catch(err){failed++;if(/sessão|Token Roblox/i.test(String(err.message)))throw err;}
        }
        return {ok:true,added,failed};
      }
    }
  })().then(data=>reply({ok:true,...data})).catch(e=>reply({ok:false,error:String(e?.message||e)}));
  return true;
});

// Batching de jogos: um rascunho persistente por conta. Cada jogo aparece uma vez,
// com sua ultima operacao; nenhum clique intermediario chega ao servidor.
const RS_DRAFT_PREFIX='roshelf_pending_games_0125_';
const rsGameLocks=new Map();
const rsDraftTabs=new Map();
function rsValidOwner(id){return /^[1-9][0-9]{0,18}$/.test(String(id||''));}
async function roshelfStageGame(ownerId,change,tabId){
  if(!rsValidOwner(ownerId)||!change||!['add','remove'].includes(change.op))throw Error('Rascunho invalido.');
  const universeId=String(change.op==='add'?change.game?.universe_id:change.universe_id);
  if(!rsValidOwner(universeId))throw Error('Jogo invalido.');
  const session=await roshelfSession();
  if(String(session?.id)!==String(ownerId))throw Error('Conta diferente da conectada.');
  const key=RS_DRAFT_PREFIX+ownerId;
  const draft=(await chrome.storage.local.get(key))[key]||{};
  if(Object.keys(draft).length>500)throw Error('Limite de alteracoes pendentes atingido. Salve esta lista.');
  draft[universeId]=change;
  await chrome.storage.local.set({[key]:draft});
  if(tabId!=null)rsDraftTabs.set(tabId,String(ownerId));
  return {ok:true,pending:Object.keys(draft).length};
}
const RS_LAYOUT_PREFIX='roshelf_pending_layout_0126_';
async function roshelfStageLayout(ownerId,lists,tabId){
  if(!rsValidOwner(ownerId)||!Array.isArray(lists)||lists.length>20)throw Error('Layout inválido.');
  const session=await roshelfSession();
  if(String(session?.id)!==String(ownerId))throw Error('Conta diferente da conectada.');
  if(lists.some(x=>!x||typeof x.category_id!=='string'||!Array.isArray(x.games)||x.games.length>3000||x.games.some(id=>!rsValidOwner(id))))throw Error('Layout inválido.');
  await chrome.storage.local.set({[RS_LAYOUT_PREFIX+ownerId]:lists});
  if(tabId!=null)rsDraftTabs.set(tabId,String(ownerId));
  return {ok:true};
}
async function roshelfCommitGames(ownerId){
  if(!rsValidOwner(ownerId))throw Error('Conta invalida.');
  if(rsGameLocks.has(String(ownerId)))return await rsGameLocks.get(String(ownerId));
  const promise=(async()=>{
    const key=RS_DRAFT_PREFIX+ownerId;
    // Snapshot: novos cliques durante o envio ficam para o proximo commit.
    const draft=(await chrome.storage.local.get(key))[key]||{};
    const entries=Object.entries(draft);
    let applied=0;
    for(const [uid,op] of entries){
      const current=(await chrome.storage.local.get(key))[key]||{};
      if(JSON.stringify(current[uid])!==JSON.stringify(op))continue;
      if(op.op==='add')await roshelfRequest('POST',null,'add',{category:op.category,category_id:op.category_id,game:op.game});
      else await roshelfRequest('POST',null,'remove',{universe_id:uid});
      const latest=(await chrome.storage.local.get(key))[key]||{};
      if(JSON.stringify(latest[uid])===JSON.stringify(op)){
        delete latest[uid];await chrome.storage.local.set({[key]:latest});
      }
      applied++;
    }
    // A more recent layout draft can be saved on the next commit.
    const layoutKey=RS_LAYOUT_PREFIX+ownerId;
    const layout=(await chrome.storage.local.get(layoutKey))[layoutKey];
    if(Array.isArray(layout)){
      await roshelfRequest('POST',null,'layout_save',{lists:layout});
      const currentLayout=(await chrome.storage.local.get(layoutKey))[layoutKey];
      if(JSON.stringify(currentLayout)===JSON.stringify(layout))await chrome.storage.local.remove(layoutKey);
    }
    return {ok:true,applied};
  })();
  rsGameLocks.set(String(ownerId),promise);
  try{return await promise}finally{rsGameLocks.delete(String(ownerId))}
}
// Ao fechar a aba, o worker ainda consegue iniciar o envio independente dela.
chrome.tabs.onRemoved.addListener(tabId=>{
  const ownerId=rsDraftTabs.get(tabId);rsDraftTabs.delete(tabId);
  if(ownerId)void roshelfCommitGames(ownerId).catch(e=>console.warn('RoShelf: jogos ainda pendentes no dispositivo',e.message));
});
// Recupera rascunhos de fechamento inesperado na proxima inicializacao.
async function rsRecoverPendingGames(){
  const entries=await chrome.storage.local.get(null);
  for(const key of Object.keys(entries))if((key.startsWith(RS_DRAFT_PREFIX)&&Object.keys(entries[key]||{}).length)||(key.startsWith(RS_LAYOUT_PREFIX)&&Array.isArray(entries[key]))){
    const owner=key.slice(key.startsWith(RS_LAYOUT_PREFIX)?RS_LAYOUT_PREFIX.length:RS_DRAFT_PREFIX.length);
    void roshelfCommitGames(owner).catch(()=>{});
  }
}
void rsRecoverPendingGames();
